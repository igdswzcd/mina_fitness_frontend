// pages/coach/arrange.js
const app = getApp()
const {
	formatTime
} = require("../../utils/util")
Page({

	/**
	 * 页面的初始数据
	 */
	data: {
		timeSections: ['09:00-10:00', '10:00-11:00', '11:00-12:00', '14:00-15:00', '15:00-16:00', '16:00-17:00', '17:00-18:00', '19:00-20:00', '20:00-21:00'],
		datesFirst: null,
		datesSecond: null,
		temp: [1, 2, 3, 4, 5, 6, 7, 8, 9],
		dateIndex: 1,
		applyRecords: null,
		showActionSheet: false
	},
	tapArrow(e) {
		var di = this.__data__.dateIndex == 1 ? 2 : 1
		this.setData({
			dateIndex: di,
			lrControl: !this.__data__.lrControl
		})
		this.setData({
			selectIndex: null
		})
	},
	/**
	 * 生命周期函数--监听页面加载
	 */
	onLoad: function (options) {
		var d = new Date()
		var st = formatTime(d).split(" ")[0].replace(/\//g, "-")
		d.setDate(d.getDate() + 9)
		var et = formatTime(d).split(" ")[0].replace(/\//g, "-")
		this.setData({
			startDate: st,
			endDate: et
		})
		var set1 = []
		var set2 = []
		for (var i = 0; i < 45; ++i) {
			set1.push(3)
			set2.push(3)
		}
		this.setData({
			classSet1: set1,
			classSet2: set2
		})
		var d = new Date()
		var temp = new Array()
		for (var i = 0; i < 10; i++) {
			var currentDate = formatTime(d).split(" ")[0].substr(5)
			temp[i] = currentDate
			d.setDate(d.getDate() + 1)
		}
		this.setData({
			datesFirst: temp.splice(0, 5),
			datesSecond: temp.splice(0, 5)
		})
		this.getApply()
	},
	getApply() {
		wx.request({
            method: 'GET',
            url: 'http://81.68.229.2:686/APPOINTMENT-MODULE-SERVER/appointment/trainer/notReviewedTimes',
            header:{
                Authorization: app.globalData.token
            },
            data:{
                startTime: this.__data__.startDate + ' 09:00:00',
                endTime: this.__data__.endDate + ' 21:00:00'
            },
            success: results => {
                this.setData({
                    applyRecords: results.data.data
                })
                this.getClasses()
            }
        })
	},
	getClasses() {
		wx.request({
			method: 'GET',
			url: 'http://81.68.229.2:686/APPOINTMENT-MODULE-SERVER/course/get/template',
			header: {
				Authorization: app.globalData.token
			},
			data: {
				endDate: this.__data__.endDate,
				startDate: this.__data__.startDate,
				trainerId: app.globalData.uid
			},
			success: results => {
				var res = results.data.data
				var tmpSet1 = this.__data__.classSet1
				var tmpSet2 = this.__data__.classSet2
				for (var i = 0; i < 45; ++i) {
					tmpSet1[i] = res[i]
					if (res[i].course_info != null) {
						if (res[i].course_info.reserved > 0) {
							tmpSet1[i].type = 2
						}
					}
					tmpSet2[i] = res[i + 45]
					if (res[i + 45].course_info != null) {
						if (res[i + 45].course_info.reserved > 0) {
							tmpSet2[i].type = 2
						}
					}
				}
				this.setData({
					rawData: res,
					classSet1: tmpSet1,
					classSet2: tmpSet2
				})
				this.checkReserved()
			}
		})
	},
	checkReserved(){
        var applyed = this.__data__.applyRecords
        for(var i = 0; i < applyed.length; ++i){
            var idx = this.timeToIndex(applyed[i])
            if(idx < 0){
                continue
            }
            if(idx > 44){
                var tmp = this.__data__.classSet2
                tmp[idx-45].type = 2
                this.setData({
                    classSet2: tmp,
                    selectIndex: null
                })
            }
            else{
                var tmp = this.__data__.classSet1
                tmp[idx].type = 2
                this.setData({
                    classSet1: tmp,
                    selectIndex: null
                })
            }
        }
	},
	timeToIndex(targetTime){
        var targetDate = targetTime.split(" ")[0].split("-")
        var targetHour = targetTime.split(" ")[1].split(":")[0]
        var hourIndex = -1;
        for(var i = 0; i < this.__data__.timeSections.length; ++i){
            var hour = this.__data__.timeSections[i].substr(0,2)
            if(targetHour == hour){
                hourIndex = i;
            }
        }
        var sd = this.__data__.startDate.split("-")
        var d1 = new Date()
        d1.setFullYear(targetDate[0],targetDate[1]-1,targetDate[2])
        d1.setHours(0,0,0,0)

        var d2 = new Date()
        d2.setFullYear(sd[0],sd[1]-1,sd[2])
        d2.setHours(0,0,0,0)
        var distance = (d1.getTime()-d2.getTime())/3600/24/1000
        return distance*9+hourIndex
    },
	tapClass(e) {
		var tmp = [e.target.dataset.dindex, e.target.dataset.tindex]
		var selectedClassInRaw = this.__data__.rawData[this.__data__.dateIndex * 45 - 45 + tmp[0] * 9 + tmp[1]]
		console.log(selectedClassInRaw)
		console.log(tmp)
		if (selectedClassInRaw.type == 2) {
			wx.showModal({
				title: '提示',
				content: '该时段已有学员申请或已预约，不可以再修改了~',
				showCancel: false
			})
		} else if (selectedClassInRaw.type == 0) {
			this.setData({
				showActionSheet: true,
				selectedClass: selectedClassInRaw,
				selectIndex: tmp,
				groups: [{
						text: '新建私教课程',
						value: 1
					},
					{
						text: '新建体验课程',
						value: 2
					}
				]
			})
		} else if (selectedClassInRaw.type == 1) {
			this.setData({
				showActionSheet: true,
				selectedClass: selectedClassInRaw,
				selectIndex: tmp,
				groups: [{
					text: '删除课程',
					type: 'warn',
					value: 3
				}]
			})
		}
	},
	tapActionSheet(e) {
		if (e.detail.value == 1) {
			wx.showModal({
				title: '确认',
				content: '是否确认新建私教课程？',
				success: results => {
					if (results.confirm == true) {
						this.createNormalClass(this.__data__.selectedClass.time)
						this.setData({
							selectIndex: null
						})
					}
				},
			})
		} else if (e.detail.value == 2) {
			wx.showModal({
				title: '确认',
				content: '是否确认新建体验课程？',
				success: results => {
					if (results.confirm == true) {
						this.createTrialClass(this.__data__.selectedClass.time)
						this.setData({
							selectIndex: null
						})
					}
				},
			})
		} else if (e.detail.value == 3) {
			wx.showModal({
				title: '确认',
				content: '是否确认删除课程？',
				success: results => {
					if (results.confirm == true) {
						this.deleteEmptyClass(this.__data__.selectedClass.course_info.courseId)
						this.setData({
							selectIndex: null
						})
					}
				},
			})
		}
		this.setData({
			showActionSheet: false
		})
	},
	createNormalClass(startTime) {
		console.log(startTime)
		wx.request({
			method: 'PUT',
			url: 'http://81.68.229.2:686/APPOINTMENT-MODULE-SERVER/course/create',
			header: {
				Authorization: app.globalData.token
			},
			data: {
				costPeriod: 1,
				description: 'from_wx',
				limit: 1,
				startTime: startTime,
				trainerId: app.globalData.uid,
				type: 0
			},
			success: results => {
				console.log(results)
				this.getApply()
			}
		})
	},
	createTrialClass(startTime){
		wx.request({
			method: 'PUT',
			url: 'http://81.68.229.2:686/APPOINTMENT-MODULE-SERVER/course/create',
			header: {
				Authorization: app.globalData.token
			},
			data: {
				costPeriod: 0,
				description: 'from_wx',
				limit: 5,
				startTime: startTime,
				trainerId: app.globalData.uid,
				type: 1
			},
			success: results => {
				this.getApply()
			}
		})
	},
	deleteEmptyClass(cid){
		wx.request({
			method: 'DELETE',
			url: 'http://81.68.229.2:686/APPOINTMENT-MODULE-SERVER/course/remove',
			header: {
				Authorization: app.globalData.token
			},
			data: {
				courseId: cid
			},
			success: results => {
				this.getApply()
			}
		})
	},
	templateCreate(){
		var tmp = this.__data__.rawData
		var emptyCount = 0;
		var currentTime = null;
		for(var i = 89; i >= 0; --i){
			if(tmp[i].type == 1){
				break
			}
			else if(tmp[i].type == 0){
				emptyCount++
				if(i%9==0){
					currentTime = tmp[i].time
				}
			}
		}
		if(emptyCount < 9){
			wx.showModal({
			  showCancel: false,
			  title: '提示',
			  content: '空余天数不足或最后n天都已有安排'
			})
		}
		else{
			wx.showModal({
				showCancel: false,
				title: '提示',
				content: '新建成功！'
			  })
			wx.request({
				method: 'PUT',
				url: 'http://81.68.229.2:686/APPOINTMENT-MODULE-SERVER/course/create/template',
				header: {
					Authorization: app.globalData.token
				},
				data: {
					days: Math.floor(emptyCount/9),
					startDate: currentTime.split(" ")[0]
				},
				success: results => {
					this.getApply()
				}
			})
		}
	},
	onPullDownRefresh(){
		this.getApply()
		wx.stopPullDownRefresh()
	}
})