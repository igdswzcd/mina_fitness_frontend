// pages/coach/students.js
const app = getApp()
Page({

	/**
	 * 页面的初始数据
	 */
	data: {
		coachInfo: null,
		students: null,
		inputText: '',
		targetId: 'uid'
	},

	tapChat(e){
		this.setData({
			targetId: this.__data__.students[e.currentTarget.dataset.index].id
		})
	},
	bindInput(e){
		this.setData({
			inputText: e.detail.value
		})
	},
	tapSubmit(){
		wx.request({
			method: 'POST',
			url: 'http://81.68.229.2:686/APPOINTMENT-MODULE-SERVER/message/chat',
			header:{
				Authorization: app.globalData.token
			},
			data:{
				content: this.__data__.inputText,
  				senderId: app.globalData.uid,
  				targetId: this.__data__.targetId
			},
			success: results => {
				this.setData({
					inputText: ''
				})
			}
		})
	},
	/**
	 * 生命周期函数--监听页面加载
	 */
	onLoad: function () {
		this.getCoach()
	},
	getCoach(){
		wx.request({
			method: 'GET',
			url: 'http://81.68.229.2:686/MANAGE-MODULE-SERVER/shopkeeper/coach/info',
			header:{
				Authorization: app.globalData.token
			},
			data:{
			  cid: app.globalData.uid
			},
			success: results => {
				this.setData({
					coachInfo: results.data.content
				})
				var stus = results.data.content.students
				var tmp = []
				for(var i = 0; i < stus.length; ++i){
					tmp[i] = 0
				}
				this.setData({
					students: tmp
				})
				for(var i = 0; i <stus.length; ++i){
					this.getStudent(stus[i].uid, i)
				}
			}
		})
	},
	getStudent(sid, idx){
		wx.request({
			method: 'GET',
			url: 'http://81.68.229.2:686/USER-MODULE-SERVER/user/get',
			header:{
				Authorization: app.globalData.token
			},
			data:{
			  id: sid
			},
			success: results => {
				var tmp = this.__data__.students
				tmp[idx] = results.data.content
				this.setData({
					students: tmp
				})
			}
		})
	},
	/**
	 * 页面相关事件处理函数--监听用户下拉动作
	 */
	onPullDownRefresh: function () {
		this.getCoach()
		this.getReserveRecord()
	}
})