const app = getApp()
Page({
	data: {
		// 第二页
		showTopTips: false,
		age: 0,
		ageRange: null,
		genderValue: 1,
		phone: null,
		address: null,
        radioItems: [
            {name: '男', value: 1, checked: true},
            {name: '女', value: 2}
		],
		// 第三页
		// 身高，范围为130~230，范围包括小数
		heightIndex: null,
		heightRange: null,
		// 体重，范围为35~150，范围包括小数
		weightIndex: null,
		weightRange: null,
		// 体脂率，范围为2~50,范围包括小数
		bodyFatIndex: null,
		bodyFatRange: null,
		// 基础代谢率，范围为120~250,范围包括小数
		bmrIndex: null,
		bmrRange: null,
		// 心率，范围为30~120,范围包括小数
		heartRateIndex: null,
		heartRateRange: null,
		
		// 第四页 
		gyms: null,
		selectedGymId: null,
		selectedManagerId: null,
		// 第五页
		coachs: null,
		selectedCoachId: null
	},
	radioChange(e){
		this.setData({
			genderValue: parseInt(e.detail.value)
		})
	},
	ageChange(e){
		this.setData({
			age: parseInt(e.detail.value)
		})
	},
	phoneChange(e){
		this.setData({
			phone: e.detail.value
		})
	},
	addressChange(e){
		this.setData({
			address: e.detail.value
		})
	},
	submitForm(e) {
		this.bindPersonInfo()
	},
	bindPersonInfo(){
		wx.request({
			method: 'PUT',
			url: 'http://81.68.229.2:686/USER-MODULE-SERVER/user/update',
			header: {
				Authorization: app.globalData.token
			},
			data: {
				address: this.__data__.address,
				age: this.__data__.age,
				gender: this.__data__.genderValue,
				id: app.globalData.uid,
				phone: this.__data__.phone
			},
			success: results => {
				this.bindHealth()
			}
		})
	},
	bindHealth(){
		var he = this.__data__.heightIndex[0] + 130 + this.__data__.heightIndex[1] / 10.0
		var we = this.__data__.weightIndex[0] + 35 + this.__data__.weightIndex[1] / 10.0
		var bf = this.__data__.bodyFatIndex[0] + 2 + this.__data__.bodyFatIndex[1] / 10.0
		var bmr = this.__data__.bmrIndex[0] + 120 + this.__data__.bmrIndex[1] / 10.0
		var hr = this.__data__.heartRateIndex[0] + 30 + this.__data__.heartRateIndex[1] / 10.0
		wx.request({
			method: 'PUT',
			url: 'http://81.68.229.2:686/USER-MODULE-SERVER/body/update',
			header: {
				Authorization: app.globalData.token
			},
			data: {
				bmi: (we / he / he * 100.0 * 100.0).toFixed(2),
				bodyFat: bf,
				heartRate: hr,
				height: he,
				metabolic: bmr,
				userId: app.globalData.uid,
				weight: we
			},
			success: results => {
				this.bindCoach()
			}
		})
	},
	bindCoach(){
		wx.request({
			method: 'POST',
			url: 'http://81.68.229.2:686/APPOINTMENT-MODULE-SERVER/message/choose/trainer',
			header: {
				Authorization: app.globalData.token
			},
			data: {
				shopOwnerId: this.__data__.selectedManagerId,
				studentId: app.globalData.uid,
				trainerId: this.__data__.selectedCoachId
			},
			success: results => {
				wx.redirectTo({
				  url: '../../pages/menu/menu',
				})
			}
		})
	},
	heightChange(e) {
		this.setData({
			heightIndex: e.detail.value
		})
	},

	weightChange(e) {
		this.setData({
			weightIndex: e.detail.value
		})
	},
	bodyFatChange(e) {
		this.setData({
			bodyFatIndex: e.detail.value
		})
	},
	bmrChange(e) {
		this.setData({
			bmrIndex: e.detail.value
		})
	},
	heartRateChange(e) {
		this.setData({
			heartRateIndex: e.detail.value
		})
	},

	// 将浮点数转换为整数分数两部分
	floatTrans(num) {
		var res1 = parseInt(num)
		var res2 = (10 * (num - res1)).toFixed(0)
		return [res1, res2]
	},

	// 多选picker数据生成，生成一个包含两个数组的数组，其中一个是整数位，另一个是小数位，start，end指定整数位范围
	multiRangeCreator(start, end) {
		var tempList1 = new Array();
		var i = 0,
			j = 0
		for (i = 0, j = start; j < end; i++, j++) {
			tempList1[i] = j
		}
		var tempList2 = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
		return [tempList1, tempList2]
	},
	/**
	 * 生命周期函数--监听页面加载
	 */
	getHealthyData() {
		var health = {height: 170.0, weight: 60.0, bodyFat: 20.0, metabolic: 150.0, heartRate: 80.0}
		this.initRange(health)
	},
	initRange(res) {
		var tempList = this.multiRangeCreator(130, 231)
		var indexData = this.floatTrans(res.height)
		this.setData({
			heightRange: tempList,
			heightIndex: [indexData[0] - 130, indexData[1]]
		})
		// 体重
		tempList = this.multiRangeCreator(35, 151)
		indexData = this.floatTrans(res.weight)
		this.setData({
			weightRange: tempList,
			weightIndex: [indexData[0] - 35, indexData[1]]
		})
		// 体脂
		tempList = this.multiRangeCreator(2, 51)
		indexData = this.floatTrans(res.bodyFat)
		this.setData({
			bodyFatRange: tempList,
			bodyFatIndex: [indexData[0] - 2, indexData[1]]
		})
		// 基础代谢率
		tempList = this.multiRangeCreator(120, 251)
		indexData = this.floatTrans(res.metabolic)
		this.setData({
			bmrRange: tempList,
			bmrIndex: [indexData[0] - 120, indexData[1]]
		})
		// 心率
		tempList = this.multiRangeCreator(30, 121)
		indexData = this.floatTrans(res.heartRate)
		this.setData({
			heartRateRange: tempList,
			heartRateIndex: [indexData[0] - 30, indexData[1]]
		})
	},
	getGyms(){
		wx.request({
			method: 'GET',
			url: 'http://81.68.229.2:686/MANAGE-MODULE-SERVER/admin/gym/all',
			header: {
			  Authorization: app.globalData.token
			},
			success: results => {
			  var tmp = results.data.content
			  var tar = []
			  for(var i = 0; i < tmp.length; ++i){
				  if(tmp[i].address != null){
					  tar.push({gid:tmp[i].gid, gymName: tmp[i].idName, address: tmp[i].address, pic: tmp[i].picture, checked: false, mid: tmp[i].shopkeeperId})
					  if(i == 0){
						  tar[0].checked = true
						  this.setData({
							  selectedGymId: tar[0].gid,
							  selectedManagerId: tar[0].mid
						  })
						  this.getCoachs(tar[0].gid)
					  }
				  }
			  }
			  this.setData({
				  gyms: tar
			  })
			}
		})
	},
	gymChange(e){
		if(this.__data__.selectedGymId != parseInt(e.detail.value.split(",")[0])){
			this.setData({
				selectedGymId: parseInt(e.detail.value.split(",")[0]),
				selectedManagerId: parseInt(e.detail.value.split(",")[1])
			})
			this.getCoachs(parseInt(e.detail.value))
		}
	},
	getCoachs(gid){
		wx.request({
			method: 'GET',
			url: 'http://81.68.229.2:686/MANAGE-MODULE-SERVER/shopkeeper/coach/all',
			header: {
			  Authorization: app.globalData.token
			},
			data: {
				gid: gid
			},
			success: results => {
				var tmp = results.data.content
				var tar = []
				for(var i = 0; i < tmp.length; ++i){
					tar.push({coachId:tmp[i].id, coachName: tmp[i].name, pic: tmp[i].avatar, checked: false})
					if(i == 0){
						tar[0].checked = true
						this.setData({
							selectedCoachId: tar[0].coachId
						})
					}
				}
				this.setData({
					coachs: tar
				})
				
			}
		})
	},
	coachChange(e){
		if(this.__data__.selectedCoachId != parseInt(e.detail.value)){
			this.setData({
				selectedCoachId: parseInt(e.detail.value)
			})
		}
	},
	onLoad: function (options) {
		this.setData({
			age: 20,
			genderValue: 1
		})
		var tmpAgeRange = []
		for(var i = 0; i < 120; i++){
		tmpAgeRange[i] = i
		}
		this.setData({
			ageRange: tmpAgeRange
		})
		this.getHealthyData()
		this.getGyms()
		// 身高
	}
	
})