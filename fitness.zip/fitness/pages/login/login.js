// login.js
// 获取应用实例
const app = getApp()

Page({
  data: {
    // 登录按钮文字
    wxLoginText: '一键访问',
    // 登录加载动画
    loginLoading: false,
    selectType: '',
    // 是否有微信用户信息，否则显示登录框
    hasUserInfo: false,
    // 是否已双号绑定，否则显示输入表单
    hasBinded: true,
    // 账号是否已注册，默认登录态，否则注册态
    hasRegistered: true,
    // 承载登陆注册接口返回的信息
    wxLoginData: {},
    // 小程序用户唯一标识
    opid: null,
    // 表单数据
    inputData: '',
    // 表单按钮文本
    inputBtnText: '登录',
    // 用户名输入
    emailInput: '',
    // 顶部消息提醒
    bindTopTip: '',
    // 顶部错误提醒
    errorTopTip: '',
    // 验证码加载动画
    vcLoading: false,
    vcBtnType: 'primary',
    vcText: 'GET',
    vcDisStyle: '',
    // 间距控制
    phd: 400
  },
  onLoad: function (options) {
    app.globalData.userInfo = null
    app.globalData.userData = null
  },
  tapTypeAP(e) {
    this.setData({
      selectType: 'AP',
      hasUserInfo: true,
      hasBinded: false
    })
  },
  tapTypeOB(e){
    this.setData({
      selectType: 'OP'
    })
    this.GetUserInfo()
  },
  // 获取微信用户信息
  GetUserInfo(e) {
    this.setData({
      loginLoading: true,
      wxLoginText: ''
    }),
    // 获取微信账号个人信息，与健身系统个人信息不同
    wx.getUserProfile({
      desc:'正在获取',
      success: res => {
        app.globalData.userInfo = res.userInfo
        // 获取登录码
        this.wxCode()
      },
      fail: err => {
        this.setData({
          loginLoading: false,
          wxLoginText: '登录'
        }),
        console.log("获取失败: ",err)
      }
    })
  },
  // 获取登录码并向后端请求转发获得openid
  wxCode(e){
    wx.login({
      success: res => {
        if (res.code) {
          //发起网络请求
          wx.request({
            method: 'POST',
            url: 'http://81.68.229.2:686/user/wx_login',
            data: {
              code: res.code
            },
            success: results => {
              this.setData({
                wxLoginData: results.data,
                opid: results.data.data.openid
              }),
              // 等待一秒，前往验证是否绑定
              setTimeout(() => {
                this.hasRegi()
              }, 1000);
            }
          })
        } else {
          console.log('登录失败！' + res.errMsg)
        }
      }
    })
  },
  // 验证是否绑定，状态码为0则已绑定，直接跳转
  hasRegi(e){
    if (this.__data__.wxLoginData.data.status===0){
      this.loginComplete()
    } else {
      this.setData({
        hasUserInfo: true,
        loginLoading: false,
        hasBinded: false,
        bindTopTip: '请注册/绑定一个账号以便跨平台使用此服务'
      })
    }
  },
  // 存储登录数据并跳转
  loginComplete(){
    app.globalData.userData = this.__data__.wxLoginData
    app.globalData.token = this.__data__.wxLoginData.data.token
    app.globalData.uid = this.__data__.wxLoginData.data.uid
    app.globalData.isCoach = this.__data__.wxLoginData.data.type==2?true:false
    wx.request({
			method: 'GET',
			url: 'http://81.68.229.2:686/USER-MODULE-SERVER/body/get',
			header: {
				Authorization: app.globalData.token
			},
			success: results => {
				var res = results.data.content
				if (app.globalData.userData.data.type == 3 && res.height == null) {
					wx.redirectTo({
            url: '../../pages/init/init',
          })
        }
        else{
          wx.redirectTo({
            url: '../../pages/menu/menu'
          })
        }
			}
		})
  },
  // 表单提交相关操作
  formSubmit(e){
    var _account = e.detail.value.account
    var _password = e.detail.value.password
    var _repwd = e.detail.value.repwd
    var _vcode = e.detail.value.vcode
    var _username = e.detail.value.username
    // var _accValid = /^[a-zA-Z0-9]+$/.test(_account)
    // var _pwdValid = /^[a-zA-Z0-9]+$/.test(_password)
    // 长度验证 
    if(_account.length < 4 || _account.length > 20 || _password.length < 6 || _password.length > 20){
      this.errorTip('账号/用户名长度4~20，密码长度6~20')
    } else if(this.__data__.hasRegistered){
      this.netLogin(_account, _password)
    } else if(!this.__data__.hasRegistered){
      if(_repwd != _password){
        this.errorTip('密码不相同')
      } else if(_username.length < 4 || _username.length > 12){
        this.errorTip('用户名长度须为4~12个字符')
      } else{
        if(_vcode.length != 6){
          this.errorTip('请输入正确的验证码')
        } else{
          this.netRegister(_account, _password, _username, _vcode)
        }
      }
      
    }
  },
  netLogin(acc, pwd){
    
    var _isWX = this.__data__.selectType=='AP'?false:true
    var _opid = this.__data__.opid
    console.log('netLogin isWX opid',_isWX, _opid)
    wx.request({
      method: 'POST',
      url: 'http://81.68.229.2:686/user/login',
      data: {
        account: acc,
        isWX: _isWX,
        openid: _opid,
        password: pwd
      },
      success: results => {
        this.setData({
          wxLoginData: results.data
        }),
        this.accountLoginJudge(this.__data__.wxLoginData.data.status)
      }
    })
  },
  netRegister(em, pwd, un, vc){
    var _isWX = this.__data__.selectType=='AP'?false:true
    var _opid = this.__data__.opid
    console.log('netRegi isWX opid',_isWX, _opid)
    wx.request({
      method: 'POST',
      url: 'http://81.68.229.2:686/user/register',
      data: {
        email: em,
        isWX: _isWX,
        openid: _opid,
        password: pwd,
        username: un,
        verificationCode: vc
      },
      success: results => {
        this.setData({
          wxLoginData: results.data
        }),
        this.accountRegiJudge(this.__data__.wxLoginData.data.status, em, pwd)
      }
    })
  },
  accountLoginJudge(sts){
    console.log('LoginJudge', sts)
    if(sts==0){
      console.log('Login OK!')
      this.loginComplete()
    } else if(sts==1){
      this.errorTip('账号不存在')
      this.setData({
        hasRegistered: false,
        inputBtnText: '注册',
        phd: 200
      })
    } else if(sts==2){
      this.errorTip('密码错误')
      this.setData({
        hasRegistered: true,
        inputBtnText: '登录',
        phd: 400
      })
    }
  },
  accountRegiJudge(sts, em, pwd){
    console.log('RegiJudge', sts)
    if(sts==0){
      console.log('Reg OK!')
      if(this.__data__.selectType=='AP'){
        this.netLogin(em, pwd)
        console.log('normal regi, redirect to normal login')
      }
      else{
        this.wxCode()
      }
    }
    if(sts==1){
      this.errorTip('账号已存在')
      this.setData({
        hasRegistered: true,
        inputBtnText: '登录',
        phd: 400
      })
    }
  },
  formReset(e){
      this.setData({
          inputData: ''
      })
  },
  tapDialogButton(e) {
    this.setData({
      showBindDialog: false
    })
  },
  tapBackButton(e){
    // wx.redirectTo({
    //   url: '../../pages/login/login',
    // })
    this.setData({
      opid: null,
      wxLoginData: {},
      hasBinded: true,
      hasUserInfo: false,
      wxLoginText: '一键访问',
      selectType: ''
    })
  },
  tapNaviButton(e) {
    this.setData({
      hasRegistered: this.__data__.hasRegistered?false:true,
      phd: this.__data__.phd==400?200:400,
      inputBtnText: this.__data__.hasRegistered?'注册':'登录'
    })
  },
  tapVcode(e) {
    if(this.__data__.emailInput == ''){
      this.errorTip('请填写邮箱')
    } else{
      wx.request({
        method: 'GET',
        url: 'http://81.68.229.2:686/user/get_verification_code',
        data: {
          email: this.__data__.emailInput
        }
      })
      this.setData({
        vcLoading: true,
        vcBtnType: 'default',
        vcText: ''
      })
      setTimeout(() => {
        this.setData({
          vcLoading: false,
          vcBtnType: 'primary',
          vcText: 'GET'
        })
      }, 2000);
    }
  },
  handleEmailInput(e){
    this.setData({
        emailInput:e.detail.value
    })
  },
  errorTip(str){
    this.setData({
      errorTopTip: str
    })
  }
})
