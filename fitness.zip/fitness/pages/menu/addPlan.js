const { formatTime } = require("../../utils/util")
const app = getApp()
Page({

    /**
     * 页面的初始数据
     */
    data: {
        planTypes: ["通用", "跑步", "游泳","乒乓","足球","篮球","骑行"],
        typeIndex: 0,

        startDate: null,
        endDate: null,
        dateValue: null,

        startTime: null,
        timeLimit: null,
        timeValue: null,
        durationValue: 30,
        endDate: null,
        contentValue: '',
        contentCount: 0
    },
    contentCounter(e){
        this.setData({
            contentCount: e.detail.value.length,
            contentValue: e.detail.value
        })
    },
    isLeapYear(year){
        return (year % 4 == 0) && (year % 100 != 0 || year % 400 == 0)
    },
    typeChange(e){
        console.log(e)
        this.setData({
            typeIndex: e.detail.value
        })
    },
    dateChange(e){
        console.log(e.detail.value===this.__data__.startDate)
        this.setData({
            dateValue: e.detail.value,
            timeLimit: e.detail.value===this.__data__.startDate?this.__data__.startTime:null
        })
    },
    timeChange(e){
        this.setData({
            timeValue: e.detail.value
        })
    },
    durationChange(e){
        var t = e.detail.value.split(":")
        var min = parseInt(t[0])*60+parseInt(t[1])
        this.setData({
            durationValue: min
        })
    },
    submitForm(){
        var content = '['+this.__data__.durationValue+'分钟]' + this.__data__.contentValue
        var date = this.__data__.dateValue
        var title = this.__data__.planTypes[this.__data__.typeIndex]+'计划'

        wx.showModal({
			title: '确认',
			content: '是否确认提交？',
			showCancel: true,
			confirmText: '确定',
			cancelText: '取消',
			success(res) {
				if(res.confirm == true){
					wx.request({
						method: 'POST',
                        url: 'http://81.68.229.2:686/USER-MODULE-SERVER/plan/add',
                        header: {
                            Authorization: app.globalData.token
                        },
						data: {
                            content: content,
                            date: date,
                            status: 0,
                            title: title,
                            userId: app.globalData.uid
						},
						success: results => {
							setTimeout(() => {
								wx.redirectTo({
								url: 'menu',
								})
							}, 200);
						}
					})
				}
			}
		})
    },

    /**
     * 生命周期函数--监听页面加载
     */
    onLoad: function (options) {
        var fulltime = formatTime(new Date)
        var date = fulltime.split(" ")[0].replace(/\//g, "-")
        var time = fulltime.split(" ")[1].substr(0,5)

        var year = parseInt(date.split("-")[0])
        var month = parseInt(date.split("-")[1])
        var febDays = 0

        if(month === 12){
            if(this.isLeapYear(year+1)){
                febDays = 1
            }
            else febDays = 0
        } else{
            febDays = this.isLeapYear(year)?1:0
        }
        
        var _days = [31, 28+febDays, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]
        var endMonth = month+2
        year = endMonth>12?year+1:year
        endMonth = endMonth>12?endMonth-12:endMonth
        var endDays = _days[endMonth-1]
        endMonth = endMonth<10?"0"+endMonth:toString(endMonth)
        this.setData({
            startDate: date,
            dateValue: date,
            endDate: year+"-"+endMonth+"-"+endDays,
            startTime: time,
            timeValue: time,
            timeLimit: time
        })
    }
})