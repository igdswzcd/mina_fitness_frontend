// pages/menu/healthChange.js
const app = getApp()
Page({

	/**
	 * 页面的初始数据
	 */
	data: {
		// 身高，范围为130~230，范围包括小数
		heightIndex: null,
		heightRange: null,
		// 体重，范围为35~150，范围包括小数
		weightIndex: null,
		weightRange: null,
		// BMI由身高体重动态算出
		bmiValue: null,
		// 体脂率，范围为2~50,范围包括小数
		bodyFatIndex: null,
		bodyFatRange: null,
		// 基础代谢率，范围为120~250,范围包括小数
		bmrIndex: null,
		bmrRange: null,
		// 心率，范围为30~120,范围包括小数
		heartRateIndex: null,
		heartRateRange: null
	},
	submitForm(e) {
		var he = this.__data__.heightIndex[0] + 130 + this.__data__.heightIndex[1] / 10.0
		var we = this.__data__.weightIndex[0] + 35 + this.__data__.weightIndex[1] / 10.0
		var bmi = parseFloat(this.__data__.bmiValue)
		var bf = this.__data__.bodyFatIndex[0] + 2 + this.__data__.bodyFatIndex[1] / 10.0
		var bmr = this.__data__.bmrIndex[0] + 120 + this.__data__.bmrIndex[1] / 10.0
		var hr = this.__data__.heartRateIndex[0] + 30 + this.__data__.heartRateIndex[1] / 10.0
		console.log(bmi)
		console.log(bf)
		console.log(hr)
		console.log(he)
		console.log(bmr)
		console.log(we)
		wx.showModal({
			title: '确认',
			content: '是否确认提交？',
			showCancel: true,
			confirmText: '确定',
			cancelText: '取消',
			success(res) {
				if(res.confirm == true){
					wx.request({
						method: 'PUT',
						url: 'http://81.68.229.2:686/USER-MODULE-SERVER/body/update',
						header: {
							Authorization: app.globalData.token
						},
						data: {
							bmi: bmi,
							bodyFat: bf,
							heartRate: hr,
							height: he,
							metabolic: bmr,
							userId: app.globalData.uid,
							weight: we
						},
						success: results => {
							setTimeout(() => {
								wx.redirectTo({
								url: 'menu',
								})
							}, 200);
						}
					})
				}
			}
		})
	},
	heightChange(e) {
		this.setData({
			heightIndex: e.detail.value
		})
		this.calcBMI()
	},

	weightChange(e) {
		this.setData({
			weightIndex: e.detail.value
		})
		this.calcBMI()
	},
	bodyFatChange(e) {
		this.setData({
			bodyFatIndex: e.detail.value
		})
	},
	bmrChange(e) {
		this.setData({
			bmrIndex: e.detail.value
		})
	},
	heartRateChange(e) {
		this.setData({
			heartRateIndex: e.detail.value
		})
	},
	calcBMI(e) {
		var height = this.__data__.heightIndex[0] + 130 + this.__data__.heightIndex[1] / 10
		var weight = this.__data__.weightIndex[0] + 35 + this.__data__.weightIndex[1] / 10
		console.log(height)
		console.log(weight)
		this.setData({
			bmiValue: (weight / height / height * 100.0 * 100.0).toFixed(2)
		})
	},

	// 将浮点数转换为整数分数两部分
	floatTrans(num) {
		var res1 = parseInt(num)
		var res2 = (10 * (num - res1)).toFixed(0)
		return [res1, res2]
	},

	// 多选picker数据生成，生成一个包含两个数组的数组，其中一个是整数位，另一个是小数位，start，end指定整数位范围
	multiRangeCreator(start, end) {
		var tempList1 = new Array();
		var i = 0,
			j = 0
		for (i = 0, j = start; j < end; i++, j++) {
			tempList1[i] = j
		}
		var tempList2 = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
		return [tempList1, tempList2]
	},
	/**
	 * 生命周期函数--监听页面加载
	 */
	getHealthyData() {
		wx.request({
			method: 'GET',
			url: 'http://81.68.229.2:686/USER-MODULE-SERVER/body/get',
			header: {
				Authorization: app.globalData.token
			},
			success: results => {
				console.log(results.data.content)
				var res = results.data.content
				if (res.height == null) {
					res.height = 170.0
					res.weight = 60.0
					res.bodyFat = 20.0
					res.metabolic = 150.0
					res.heartRate = 80.0
				}
				this.initRange(res)
			}
		})
	},
	initRange(res) {
		var tempList = this.multiRangeCreator(130, 231)
		var indexData = this.floatTrans(res.height)
		this.setData({
			heightRange: tempList,
			heightIndex: [indexData[0] - 130, indexData[1]]
		})
		// 体重
		tempList = this.multiRangeCreator(35, 151)
		indexData = this.floatTrans(res.weight)
		this.setData({
			weightRange: tempList,
			weightIndex: [indexData[0] - 35, indexData[1]]
		})
		this.calcBMI()
		// 体脂
		tempList = this.multiRangeCreator(2, 51)
		indexData = this.floatTrans(res.bodyFat)
		this.setData({
			bodyFatRange: tempList,
			bodyFatIndex: [indexData[0] - 2, indexData[1]]
		})
		// 基础代谢率
		tempList = this.multiRangeCreator(120, 251)
		indexData = this.floatTrans(res.metabolic)
		this.setData({
			bmrRange: tempList,
			bmrIndex: [indexData[0] - 120, indexData[1]]
		})
		// 心率
		tempList = this.multiRangeCreator(30, 121)
		indexData = this.floatTrans(res.heartRate)
		this.setData({
			heartRateRange: tempList,
			heartRateIndex: [indexData[0] - 30, indexData[1]]
		})
	},
	onLoad: function (options) {
		this.getHealthyData()
		// 身高
	},

	/**
	 * 生命周期函数--监听页面初次渲染完成
	 */
	onReady: function () {

	},

	/**
	 * 生命周期函数--监听页面显示
	 */
	onShow: function () {

	},

	/**
	 * 生命周期函数--监听页面隐藏
	 */
	onHide: function () {

	},

	/**
	 * 生命周期函数--监听页面卸载
	 */
	onUnload: function () {

	},

	/**
	 * 页面相关事件处理函数--监听用户下拉动作
	 */
	onPullDownRefresh: function () {

	},

	/**
	 * 页面上拉触底事件的处理函数
	 */
	onReachBottom: function () {

	},

	/**
	 * 用户点击右上角分享
	 */
	onShareAppMessage: function () {

	}
})