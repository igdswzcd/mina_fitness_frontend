// index.js
// 获取应用实例
const { formatTime } = require("../../utils/util")
const app = getApp()

Page({
  data: {
    isCoach: false,
    userInfo: {},
    userData: {},
    resInfo: ['?','?','?'],
    resInfoApply: '?',
    balance: '?',
    avatarUrl: null,
    personInfo: null,
    healthInfo: null,
    healthCondition: null,
    healthScore: 60,
    showActionSheet: false,
    newMsgCount: 0,
    banTrial: true,
    actionGroups: [{
        text: '修改健康数据',
        value: 1
      },
      {
        text: '修改个人信息',
        value: 2
      },
      {
        text: '修改头像',
        value: 3
      }
    ],
    showPlans: [{
      type: 0,
      title: '待添加计划',
      content: '点击加号新建运动计划!',
      date: ""
    }, {
      type: 0,
      title: '待添加计划',
      content: '点击加号新建运动计划!',
      date: ""
    }, {
      type: 0,
      title: '待添加计划',
      content: '点击加号新建运动计划!',
      date: ""
    }],
    config: {
      canvasSize: {
        width: 100,
        height: 100
      },
      percent: 100,
      barStyle: [{
        width: 20,
        fillStyle: '#f0f0f0'
      }, {
        width: 20,
        animate: true,
        fillStyle: [{
          position: 0,
          color: '#56B37F'
        }, {
          position: 1,
          color: '#c0e674'
        }]
      }],
      needDot: false
    },

    // 教练部分
    resApplys: null,
    coachSchedule: null
  },
  // 事件处理函数
  onLoad: function () {
    if (app.globalData.userData === null) {
      wx.redirectTo({
        url: '../login/login',
      })
    } else {
      this.setData({
        isCoach: app.globalData.isCoach
      })

      wx.showLoading({
        title: '加载数据中...',
      })
      setTimeout(() => {
        wx.hideLoading()
      }, 2000);
      this.setData({
        userInfo: app.globalData.userInfo,
        userData: app.globalData.userData,
      })
      if(this.__data__.isCoach==false){
      this.getCoachInfo()
      this.getInfo()
      this.getThreePlans()
      this.getHealthyData()
      }
      else{
        this.coachGetReserveApplys()
        this.coachGetSchedule()
      }
    }
  },
  onShow(){
      this.getNewMsg()
  },
  getInfo() {
    wx.request({
      method: 'GET',
      url: 'http://81.68.229.2:686/USER-MODULE-SERVER/user/get',
      header: {
        Authorization: app.globalData.token
      },
      data: {
        id: app.globalData.uid
      },
      success: results => {
        this.setData({
          personInfo: results.data.content
        })
      }
    })
    wx.request({
      method: 'GET',
      url: 'http://81.68.229.2:686/USER-MODULE-SERVER/user/image/get',
      header: {
        Authorization: app.globalData.token
      },
      success: results => {
        this.setData({
          avatarUrl: results.data.content
        })
      }
    })
  },
  getHealthyData() {
    wx.request({
      method: 'GET',
      url: 'http://81.68.229.2:686/USER-MODULE-SERVER/body/get',
      header: {
        Authorization: app.globalData.token
      },
      success: results => {
        var tmp = [0, 0, 0, 0]
        var res = results.data.content
        if (results.data.content.height != null) {
          var score = 100 - Math.abs(res.bmi - 21) - (res.bodyFat - 20) - Math.abs(res.metabolic - 150) / 2 - Math.abs(res.heartRate - 80) / 2
          if (score > 100) {
            score = 100
          }
          if (res.bmi < 18.5 || res.bmi > 24) {
            tmp[0] = 2
          } else {
            tmp[0] = 1
          }
          if (res.bodyFat > 25) {
            tmp[1] = 2
          } else {
            tmp[1] = 1
          }
          if (res.metabolic < 130 || res.metabolic > 200) {
            tmp[2] = 2
          } else {
            tmp[2] = 1
          }
          if (res.heartRate < 60 || res.heartRate > 100) {
            tmp[3] = 2
          } else {
            tmp[3] = 1
          }
          this.setData({
            healthInfo: results.data.content,
            healthCondition: tmp,
            healthScore: score
          })
        }
        else{
          this.setData({
            healthInfo: results.data.content,
            healthScore: 0,
            healthCondition: tmp
          })
        }
        
      }
    })
  },
  getNewMsg(){
    if(app.globalData.token != null){
      wx.request({
        method: 'GET',
        url: 'http://81.68.229.2:686/APPOINTMENT-MODULE-SERVER/message/get/new/server',
        header: {
          Authorization: app.globalData.token
        },
        success: results => {
          if(results.data.data.length >= 0){
            this.setData({
              newMsgCount: results.data.data.length
            })
          }
        }
      })
    }
	},
  getCoachInfo(){
    wx.request({
      method: 'GET',
      url: 'http://81.68.229.2:686/MANAGE-MODULE-SERVER/shopkeeper/coach/getCoachOfStudent',
      header: {
        Authorization: app.globalData.token
      },
      data: {
        sid: app.globalData.uid
      },
      success: results => {
        if(results.data.content.length > 0){
          app.globalData.coachInfo = results.data.content[0]
          this.getReserveInfo()
          this.getBalance()
          this.getApply()
          this.getTrialLimit()
        }
      }
    })
  },
  getThreePlans() {
    wx.request({
      method: 'GET',
      url: 'http://81.68.229.2:686/API-AGGREGATE/wx/getAllCoursesAndPlans',
      header: {
        Authorization: app.globalData.token
      },
      success: results => {
        var tmp = results.data.data.coursesAndPlans
        var validData = []
        for(var i = 0; i < tmp.length; ++i){
          if(this.checkTime(tmp[i].startTime) == true){
            validData.push(tmp[i])
          }
          if(validData.length == 3){
            break
          }
        }
        this.formatPlans(validData)
      }
    })
  },
  // type: 0,
  //     title: '待添加计划',
  //     content: '点击加号新建运动计划!',
  //     date: ""
  formatPlans(res) {
    var tmp = []
    for(var i = 0; i < res.length; ++i){
      tmp.push({
        type: res[i].type,
        title: res[i].type==1?'健身课程':res[i].title,
        content: res[i].type==1?(res[i].courseType==0?'私教课程':'体验课程'):res[i].content,
        date: res[i].startTime
      })
    }
    for(var i = tmp.length; i < 3; ++i){
      tmp.push({
        type: 2,
        title: '待添加计划',
        content: '点击加号新建运动计划!',
        date: ""
      })
    }
    this.setData({
      showPlans: tmp
    })
  },

  getReserveInfo(){
    wx.request({
      method: 'GET',
      url: 'http://81.68.229.2:686/APPOINTMENT-MODULE-SERVER/appointment/student/records',
      header:{
          Authorization: app.globalData.token
      },
      success: results => {
        var sd = new Date()
        var st = formatTime(sd).split(" ")[0].split("\/")
        sd.setFullYear(st[0], st[1]-1, st[2])
        sd.setHours(0,0,0,0)
        var res = results.data.data
        var finished = 0
        var reserved = 0
        var coming = 0
        for(var i = 0; i < res.length; ++i){
          var td = res[i].startTime.split(" ")[0].split("-")
          var d2 = new Date()
          d2.setFullYear(td[0],td[1]-1,td[2])
          d2.setHours(0,0,0,0)
          var distance = (d2.getTime()-sd.getTime())/3600/24/1000
          if(distance < 0){
            finished++
          }
          else if(distance < 2){
            coming++
            reserved++
          }
          else{
            reserved++
          }
        }
        this.setData({
          resInfo: [finished, coming, reserved]
        })
      }
    })
  },
  getApply(){
      var d = new Date()
      var st = formatTime(d).split(" ")[0].replace(/\//g, "-")
      d.setDate(d.getDate()+9)
      var et = formatTime(d).split(" ")[0].replace(/\//g, "-")
      wx.request({
          method: 'GET',
          url: 'http://81.68.229.2:686/APPOINTMENT-MODULE-SERVER/appointment/student/notReviewedTimes',
          header:{
              Authorization: app.globalData.token
          },
          data:{
              startTime: st + ' 09:00:00',
              endTime: et + ' 21:00:00'
          },
          success: results => {
              this.setData({
                resInfoApply: results.data.data.length
              })
          }
      })
  },
  getBalance(){
    wx.request({
        method: 'GET',
        url: 'http://81.68.229.2:686/APPOINTMENT-MODULE-SERVER/period/balance',
        header:{
            Authorization: app.globalData.token
        },
        success: results => {
            this.setData({
                balance: results.data.data
            })
        }
    })
  },
  getTrialLimit(){
    wx.request({
      method: 'GET',
      url: 'http://81.68.229.2:686/APPOINTMENT-MODULE-SERVER/course/experienceTime',
      header:{
          Authorization: app.globalData.token
      },
      success: results => {
          console.log(results.data.data)
          app.globalData.banTrial = results.data.data
          this.setData({
            banTrial: results.data.data
          })
      }
    })
  },
  tapInfoChange(e) {
    this.setData({
      showActionSheet: true
    })
  },
  tapMailBox(){
    wx.navigateTo({
      url: '../../pages/message/message',
    })
  },
  tapASBtn(e) {
    if (e.detail.value == 1) {
      wx.navigateTo({
        url: 'healthChange',
      })
    } else if (e.detail.value == 2) {
      wx.navigateTo({
        url: 'personInfoChange',
      })
    } else if (e.detail.value == 3) {
      this.avatarChange()
    }
  },
  avatarChange(e){
    var img = null
    wx.chooseImage({
      count: 1,
      success: results => {
        img = results.tempFilePaths[0]
        this.uploadAvatar(img)
      }
    })
  },
  uploadAvatar(src){
    wx.showLoading({
      title: '上传中...',
      mask: true,
    })
    wx.uploadFile({
      filePath: src,
      name: 'file',
      url: 'http://81.68.229.2:686/USER-MODULE-SERVER/user/image/upload',
      formData: {
        file: src
      },
      header:{
        Authorization: app.globalData.token,
        uid: app.globalData.uid
      },
      success: res => {
        wx.hideLoading()
        wx.redirectTo({
          url: 'menu'
        })
      }
    })
  },
  tapReserve(e) {
    if(app.globalData.coachInfo != null){
      wx.navigateTo({
        url: '../reserve/reserve'
      })
    }
    else{
      wx.showModal({
        title: '提示',
        showCancel: false,
        content: '您的教练绑定申请还在审核中，请耐心等待~'
      })
    }
  },
  tapCoach() {
    if(app.globalData.coachInfo != null){
      wx.navigateTo({
        url: '../stucoach/stucoach',
      })
    }
    else{
      wx.showModal({
        title: '提示',
        showCancel: false,
        content: '您的教练绑定申请还在审核中，请耐心等待~'
      })
    }
  },
  tapShop(e) {
    wx.navigateTo({
      url: '../shop/shop'
    })
  },
  tapSocial(){
    wx.navigateTo({
      url: '../social/social'
    })
  },
  tapPlanSwiper(e) {
    wx.navigateTo({
      url: '../plan/plan'
    })
  },
  tapAddPlan(e) {
    wx.navigateTo({
      url: './addPlan'
    })
  },
  refreshPer() {
    this.setData({
      healthScore: this.__data__.healthScore
    })
  },
  showInfo(){
    wx.showModal({
      title: '个人信息',
      content: '用户名: ' + this.__data__.userData.data.username + '\r\n' + '年龄: ' + this.__data__.personInfo.age + '\r\n' + '性别: ' + (this.__data__.personInfo.gender==1?'男':'女') + '\r\n' + '住址: ' + this.__data__.personInfo.address + '\r\n' + '电话: ' + this.__data__.personInfo.phone,
      showCancel: true,
      cancelColor: 'red',
      cancelText: '退出登录',
      success: res =>{
        if(res.cancel == true){
          wx.redirectTo({
            url: '../login/login',
          })
        }
      }
    })
  },
  checkTime(target){
    var today = formatTime(new Date()).split(" ")[0].split("\/")
    var targetDate = target.split("-")
    

    var d1 = new Date()
    d1.setFullYear(targetDate[0],targetDate[1]-1,targetDate[2])
    d1.setHours(0,0,0,0)

    var d2 = new Date()
    d2.setFullYear(today[0],today[1]-1,today[2])
    d2.setHours(0,0,0,0)
    var distance = (d1.getTime()-d2.getTime())
    if(distance < 0){
      return false
    }
    else{
      return true
    }
  },

  // 教练部分
  coachGetReserveApplys(){
    wx.request({
      method: 'GET',
      url: 'http://81.68.229.2:686/APPOINTMENT-MODULE-SERVER/appointment/trainer/records/apply',
      header:{
          Authorization: app.globalData.token
      },
      success: results => {
        var res = results.data.data
        var tmp = []
        for(var i = 0; i < res.length; ++i){
          if(res[i].approval == 'NOT_REVIEWED'){
            tmp.push(res[i])
          }
        }
        this.setData({
          resApplys: tmp
        })
      }
    })
  },
  coachGetSchedule(){
    wx.request({
      method: 'GET',
      url: 'http://81.68.229.2:686/APPOINTMENT-MODULE-SERVER/appointment/trainer/records',
      header:{
          Authorization: app.globalData.token
      },
      success: results => {
          console.log(results.data.data)
          this.setData({
            coachSchedule: results.data.data
          })
      }
    })
  },
  tapDeny(e){
    var idx = e.currentTarget.dataset.index
    this.coachApproval(0,this.__data__.resApplys[idx].id)
  },
  tapAccept(e){
    var idx = e.currentTarget.dataset.index
    this.coachApproval(1,this.__data__.resApplys[idx].id)
  },
  coachApproval(type, target){
    wx.request({
      method: 'POST',
      url: 'http://81.68.229.2:686/APPOINTMENT-MODULE-SERVER/appointment/trainer/approval',
      header:{
          Authorization: app.globalData.token
      },
      data:{
        agree: type,
        operationId: target,
      },
      success: results => {
          this.applyRefresh()
      }
    })
  },
  applyRefresh(){
    this.coachGetReserveApplys()
  },
  scheduleRefresh(){
    this.coachGetSchedule()
  },
  tapCoachSocial(){
    wx.navigateTo({
      url: '../social/social',
    })
  },
  tapCoachStudent(){
    wx.navigateTo({
      url: '../coach/students',
    })
  },
  tapCoachArrange(){
    wx.navigateTo({
      url: '../coach/arrange',
    })
  },
  tapExit(){
    wx.showModal({
      title: '确认',
      content: '是否退出登录，返回登录页？',
      success: res =>{
        if(res.confirm == true){
          wx.redirectTo({
            url: '../login/login',
          })
        }
      }
    })
  }
})