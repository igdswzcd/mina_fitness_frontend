// pages/menu/personInfoChange.js
const app = getApp()

Page({

	/**
	 * 页面的初始数据
	 */
	data: {
        showTopTips: false,
		age: 0,
		ageRange: null,
		genderValue: 1,
		phone: null,
		address: null,
        radioItems: [
            {name: '男', value: 1, checked: true},
            {name: '女', value: 2}
		]
	},
	radioChange(e){
		this.setData({
			genderValue: parseInt(e.detail.value)
		})
	},
	ageChange(e){
		this.setData({
			age: parseInt(e.detail.value)
		})
	},
	phoneChange(e){
		this.setData({
			phone: e.detail.value
		})
	},
	addressChange(e){
		this.setData({
			address: e.detail.value
		})
	},
	submitForm(e){
		var ad = this.__data__.address
		var ag = this.__data__.age
		var gv = this.__data__.genderValue
		var ph = this.__data__.phone
		
		wx.showModal({
			title: '确认',
			content: '是否确认提交？',
			showCancel: true,
			confirmText: '确定',
			cancelText: '取消',
			success(res) {
				if(res.confirm==true){
					wx.request({
						method: 'PUT',
						url: 'http://81.68.229.2:686/USER-MODULE-SERVER/user/update',
						header: {
							Authorization: app.globalData.token
						},
						data: {
							address: ad,
							age: ag,
							gender: gv,
							id: app.globalData.uid,
							phone: ph
						},
						success: results => {
							setTimeout(() => {
								wx.redirectTo({
								url: 'menu',
								})
							}, 200);
						}
					})
				}
			}
		})
	},
	/**
	 * 生命周期函数--监听页面加载
	 */
	onLoad: function (options) {
		wx.request({
			method: 'GET',
			url: 'http://81.68.229.2:686/USER-MODULE-SERVER/user/get',
			header: {
				Authorization: app.globalData.token
			},
			data: {
			  id: app.globalData.uid
			},
			success: results => {
				if(results.data.content.age == null){
					results.data.content.age = 20
					results.data.content.gender = 1
					results.data.content.address = ''
					results.data.content.phone = ''
				}
				this.setData({
					age: results.data.content.age,
					genderValue: results.data.content.gender==0?1:results.data.content.gender==1?1:2,
					address: results.data.content.address,
					phone: results.data.content.phone
				})
			}
		  })
		  var tmpAgeRange = []
		  for(var i = 0; i < 120; i++){
			tmpAgeRange[i] = i
		  }
		  this.setData({
			  ageRange: tmpAgeRange
		  })
	},

	/**
	 * 生命周期函数--监听页面初次渲染完成
	 */
	onReady: function () {

	},

	/**
	 * 生命周期函数--监听页面显示
	 */
	onShow: function () {

	},

	/**
	 * 生命周期函数--监听页面隐藏
	 */
	onHide: function () {

	},

	/**
	 * 生命周期函数--监听页面卸载
	 */
	onUnload: function () {

	},

	/**
	 * 页面相关事件处理函数--监听用户下拉动作
	 */
	onPullDownRefresh: function () {

	},

	/**
	 * 页面上拉触底事件的处理函数
	 */
	onReachBottom: function () {

	},

	/**
	 * 用户点击右上角分享
	 */
	onShareAppMessage: function () {

	}
})