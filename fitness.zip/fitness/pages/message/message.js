// pages/message/message.js
const app = getApp()
Page({

	/**
	 * 页面的初始数据
	 */
	data: {
		msgs: null,
		newArr: null,
		hasNew: false,
		msgTypes: ['系统', '私聊', '审核', '绑定', '解绑'],
		msgTypeColors: ['#576B95', '#10AEFF', '#FFC300', '#91D300', '#FA5151'],
		msgTypeTextColors:['white', 'white', 'black', 'white', 'white']
	},

	/**
	 * 生命周期函数--监听页面加载
	 */
	tapContent(e){
		var idx = e.currentTarget.dataset.index
		wx.showModal({
			showCancel: false,
			title: this.__data__.msgTypes[this.__data__.msgs[idx].type],
		  	content: this.__data__.msgs[idx].content
		})
	},
	onLoad: function (options) {
		this.getAllMsg()
	},
	getAllMsg(){
		wx.request({
			method: 'GET',
			url: 'http://81.68.229.2:686/APPOINTMENT-MODULE-SERVER/message/get/all',
			header: {
				Authorization: app.globalData.token
			},
			success: results => {
				var res = results.data.data.reverse()
				// notification或0代表系统通知，chat或1代表私聊，approval或2代表审核，choose_trainer或3代表绑定教练，dissolution_trainer或4代表解绑教练
				for(var i = 0; i < res.length; ++i){
					if(res[i].type=='NOTIFICATION'){
						res[i].type = 0
					}
					else if(res[i].type=='CHAT'){
						res[i].type = 1
					}
					else if(res[i].type=='APPROVAL'){
						res[i].type = 2
					}
					else if(res[i].type=='CHOOSE_TRAINER'){
						res[i].type = 3
					}
					else if(res[i].type=='DISSOLUTION_TRAINER'){
						res[i].type = 4
					}
				}
				this.setData({
					msgs: res
				})
				this.getNewMsg()
			}
		})
	},
	getNewMsg(){
		wx.request({
			method: 'GET',
			url: 'http://81.68.229.2:686/APPOINTMENT-MODULE-SERVER/message/get/new/server',
			header: {
				Authorization: app.globalData.token
			},
			success: results => {
				var res = results.data.data.reverse()
				var newArr = []
				for(var i = 0; i < this.__data__.msgs.length; i++){
					var found = false
					for(var j = 0; j < res.length; ++j){
						if(res[j].messageId == this.__data__.msgs[i].messageId){
							newArr.push(true)
							found = true
							break
						}
					}
					if(!found){
						newArr.push(false)
					}
				}
				this.setData({
					newArr: newArr
				})
				this.checkNew()
			}
		})
	},
	tapReadAll(){
		if(this.__data__.hasNew){
			wx.request({
				method: 'POST',
				url: 'http://81.68.229.2:686/APPOINTMENT-MODULE-SERVER/message/read',
				header: {
					Authorization: app.globalData.token
				},
				data: {
					messageId: this.__data__.msgs[0].messageId
				},
				success: results => {
					this.getAllMsg()
				}
			})
		}
	},
	checkNew(){
		var newArr = this.__data__.newArr
		var hasNew = false
		for(var i = 0; i < newArr.length; ++i){
			if(newArr[i] == true){
				hasNew = true
				break
			}
		}
		this.setData({
			hasNew: hasNew
		})
	},
	/**
	 * 页面相关事件处理函数--监听用户下拉动作
	 */
	onPullDownRefresh: function () {
		this.getAllMsg()
		this.getReserveRecord()
	}
})