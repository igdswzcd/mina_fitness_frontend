// pages/plan/plan.js
const { formatTime } = require("../../utils/util")
const app = getApp()
Page({

    /**
     * 页面的初始数据
     */
    data: {
        monthValue: null,
        baseMonth: null,
        season: 4,
        dayValue: null,
        days: null,
        months: null,
        showPlans:null,
        scrollTop: 0
    },
    dayChange(e){
        this.setData({
            dayValue: e.detail.value
        })
        this.pickerChangeScroll(e.detail.value[0]+1)
    },
    pickerChangeScroll(day){
        var plans = this.__data__.showPlans[this.__data__.monthValue]
        for(var i = 0; i < plans.length; ++i){
            if(plans[i].numDay >= day){
                console.log(i)
                this.setData({
                    scrollTop: (i*160-80)>=0?i*160-80:i*160
                })
                break
            }
        }
    },
    monthSwiper(e){
        this.setData({
            monthValue: e.detail.current,
            season: Math.floor((this.__data__.baseMonth+e.detail.current)/3)
        })
    },
    getPlans() {
        wx.request({
          method: 'GET',
          url: 'http://81.68.229.2:686/API-AGGREGATE/wx/getAllCoursesAndPlans',
          header: {
            Authorization: app.globalData.token
          },
          success: results => {
            var months = ['01','02','03','04','05','06','07','08','09','10','11','12']
            var d = new Date()
            var thisMonth = d.getMonth()
            this.setData({
                baseMonth: thisMonth==0?12:thisMonth+12,
                season: thisMonth==11?4:Math.floor((thisMonth+13)/3)
            })
            var res = results.data.data.coursesAndPlans
            var tmp = new Array()
            tmp[0] = new Array()        // 前一个月
            tmp[1] = new Array()        // 本月
            tmp[2] = new Array()        // 后一个月
            
            for(var i = 0; i < res.length; ++i){
                // 此处没有考虑1月和12月转换的情况
                if(res[i].startTime.split("-")[1] == months[thisMonth-1]){
                    tmp[0].push({
                        type: res[i].type,
                        title: res[i].type==1?'健身课程':res[i].title,
                        content: res[i].type==1?(res[i].courseType==0?'私教课程':'体验课程'):res[i].content,
                        date: res[i].startTime,
                        day: res[i].startTime.split("-")[2],
                        numDay: parseInt(res[i].startTime.split("-")[2])
                    })
                }
                else if(res[i].startTime.split("-")[1] == months[thisMonth]){
                    tmp[1].push({
                        type: res[i].type,
                        title: res[i].type==1?'健身课程':res[i].title,
                        content: res[i].type==1?(res[i].courseType==0?'私教课程':'体验课程'):res[i].content,
                        date: res[i].startTime,
                        day: res[i].startTime.split("-")[2],
                        numDay: parseInt(res[i].startTime.split("-")[2])
                    })
                }
                else if(res[i].startTime.split("-")[1] == months[thisMonth+1]){
                    tmp[2].push({
                        type: res[i].type,
                        title: res[i].type==1?'健身课程':res[i].title,
                        content: res[i].type==1?(res[i].courseType==0?'私教课程':'体验课程'):res[i].content,
                        date: res[i].startTime,
                        day: res[i].startTime.split("-")[2],
                        numDay: parseInt(res[i].startTime.split("-")[2])
                    })
                }
                
            }
            this.setData({
                showPlans: tmp
            })
            this.pickerChangeScroll(this.__data__.dayValue[0]+1)
          }
        })
    },
    onLoad() {
        this.getPlans()
        var fulltime = formatTime(new Date).split(" ")
        var year = parseInt(fulltime[0].split("/")[0])
        var month = parseInt(fulltime[0].split("/")[1])
        var day = parseInt(fulltime[0].split("/")[2])
        var time = fulltime[1]
        var months = ["Jan 一月", "Feb 二月", "Mar 三月", "Apr 四月", "May 五月", "June 六月", "July 七月", "Aug 八月", "Sep 九月", "Oct 十月", "Nov 十一月", "Dec 十二月"]
        var days = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]
        var startMonth = month - 1
        startMonth = startMonth<1?startMonth+12:startMonth
        var _months = new Array()
        for(var i = startMonth,  j = 0; j < 3; j++){
            _months[j] = months[startMonth-1]
            startMonth++
            if(startMonth>12){
                startMonth -= 12
            }
        }
        var _days = new Array()
        for(var i = 0; i < days[month-1]; i++){
            _days[i] = i+1
        }
        this.setData({
            months: _months,
            monthValue: 1,
            days: _days
        })
        this.setData({
            dayValue: [day-1]
        })
      }
})