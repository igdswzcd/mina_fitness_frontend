// pages/reserve/reserve.js
const { formatTime } = require("../../utils/util")
const app = getApp()

Page({

    /**
     * 页面的初始数据
     */
    data: {
        timeSections:['09:00-10:00','10:00-11:00','11:00-12:00','14:00-15:00','15:00-16:00','16:00-17:00','17:00-18:00','19:00-20:00','20:00-21:00'],
        rawData: null,
        datesFirst: null,
        datesSecond: null,
        classSet1: null,
        classSet2: null,
        reservedRecords: null,
        applyRecords: null,
        temp: [1,2,3,4,5,6,7,8,9],
        dateIndex: 1,
        lrControl: false,
        showActionSheet: false,
        startDate: null,
        endDate: null,
        groups: [
            { text: '新建预约', value: 1 },
            { text: '修改预约', value: 2 },
            { text: '删除预约', type: 'warn', value: 3 }
        ],
        selectedClass: null,
        selectIndex: null,
        modifyAppointment: false,
        originalCourseId: null,
        balance: 0
    },
    tapArrow(e){
        var di = this.__data__.dateIndex==1?2:1
        this.setData({
            dateIndex: di,
            lrControl: !this.__data__.lrControl
        })
        this.setData({
            selectIndex: null
        })
    },
    tapClass(e){
        var tmp = [e.target.dataset.dindex, e.target.dataset.tindex]
        var selectedClassInRaw = this.__data__.rawData[this.__data__.dateIndex*45-45+tmp[0]*9+tmp[1]]
        console.log(selectedClassInRaw)
        console.log(tmp)
        if(selectedClassInRaw.type == 0){
            wx.showModal({
                title: '提示',
                content: '该时段不可预约或已约满，换一个时段吧~',
                showCancel: false
            })
        }
        else if(selectedClassInRaw.type == 3){
            wx.showModal({
                title: '提示',
                content: '申请还在审核中，请耐心等待~',
                showCancel: false
            })
        }
        else if(this.__data__.modifyAppointment == false){
            if(selectedClassInRaw.type == 1){
                this.setData({
                    showActionSheet: true,
                    selectedClass: selectedClassInRaw,
                    selectIndex: tmp,
                    groups: [
                        { text: '新建预约', value: 1 }
                    ]
                })
            }
            else if(selectedClassInRaw.type == 2){
                this.setData({
                    showActionSheet: true,
                    selectedClass: selectedClassInRaw,
                    selectIndex: tmp,
                    groups: [
                        { text: '修改预约', value: 2 },
                        { text: '删除预约', type: 'warn', value: 3 }
                    ]
                })
            }
        }
        else if(this.__data__.modifyAppointment == true){
            if(this.__data__.selectIndex != null && tmp[0] == this.__data__.selectIndex[0] && tmp[1] == this.__data__.selectIndex[1]){
                this.setData({
                    selectIndex: null
                })
            }
            else if(selectedClassInRaw.type == 2){
                wx.showModal({
                    title: '提示',
                    content: '该时段为原时段或已被预约！',
                    showCancel: false
                })
            }
            else{
                this.setData({
                    selectedClass: selectedClassInRaw,
                    selectIndex: tmp
                })
            }
        }
    },
    tapActionSheet(e){
        if(e.detail.value == 1){
            wx.showModal({
                title: '确认',
                content: '是否确认预约？',
                success: results => {
                    if(results.confirm == true){
                        this.newAppointment(this.__data__.selectedClass.course_info.courseId)
                    }
                },
            })
            
        }
        else if(e.detail.value == 2){
            this.setData({
                modifyAppointment: true,
                selectIndex: null,
                originalCourseId: this.__data__.selectedClass.course_info.courseId
            })
        }
        else if(e.detail.value == 3){
            wx.showModal({
                title: '确认',
                content: '是否确认删除？',
                success: results => {
                    if(results.confirm == true){
                        this.delAppointment(this.__data__.selectedClass.course_info.courseId)
                    }
                },
            })
            
        }
        this.setData({
            showActionSheet: false
        })
    },
    modifyClose(){
        this.setData({
            modifyAppointment: false,
            selectIndex: null
        })
    },
    modifySubmit(){
        wx.showModal({
            title: '确认',
            content: '是否确认修改？'+this.__data__.originalCourseId+' to '+ this.__data__.selectedClass.course_info.courseId,
            success: results => {
                if(results.confirm == true){
                    this.modifyAppointment(this.__data__.originalCourseId, this.__data__.selectedClass.course_info.courseId)
                    this.setData({
                        modifyAppointment: false,
                        selectIndex: null
                    })
                }
            },
        })
    },
    newAppointment(courseId){
        wx.request({
            method: 'POST',
            url: 'http://81.68.229.2:686/APPOINTMENT-MODULE-SERVER/appointment/student/submit',
            header:{
                Authorization: app.globalData.token
            },
            data:{
                courseId: courseId
            },
            success: results => {
                console.log(results)
                wx.showLoading({
                  title: '请稍等...',
                })
                this.getReserveRecord()
            }
        })
    },
    modifyAppointment(ori, cur){
        wx.request({
            method: 'POST',
            url: 'http://81.68.229.2:686/APPOINTMENT-MODULE-SERVER/appointment/student/modify',
            header:{
                Authorization: app.globalData.token
            },
            data:{
                currentCourseId: cur,
                originalCourseId: ori
            },
            success: results => {
                console.log(results)
                wx.showLoading({
                  title: '请稍等...',
                })
                this.getReserveRecord()
            }
        })
    },
    delAppointment(courseId){
        wx.request({
            method: 'POST',
            url: 'http://81.68.229.2:686/APPOINTMENT-MODULE-SERVER/appointment/student/cancel',
            header:{
                Authorization: app.globalData.token
            },
            data:{
                courseId: courseId
            },
            success: results => {
                console.log(results)
                wx.showLoading({
                  title: '请稍等...',
                })
                this.getReserveRecord()
            }
        })
    },
    getBalence(){
        wx.request({
            method: 'GET',
            url: 'http://81.68.229.2:686/APPOINTMENT-MODULE-SERVER/period/balance',
            header:{
                Authorization: app.globalData.token
            },
            success: results => {
                this.setData({
                    balance: results.data.data
                })
            }
        })
    },
    balanceCharge(){
        wx.request({
            method: 'POST',
            url: 'http://81.68.229.2:686/APPOINTMENT-MODULE-SERVER/period/recharge',
            header:{
                Authorization: app.globalData.token
            },
            data:{
                amount: 10
            },
            success: results => {
                this.setData({
                    balance: results.data.data
                })
            }
        })
    },
    /**
     * 生命周期函数--监听页面加载
     */
    onLoad: function () {
        this.getBalence()
        var d = new Date()
        var st = formatTime(d).split(" ")[0].replace(/\//g, "-")
        d.setDate(d.getDate()+9)
        var et = formatTime(d).split(" ")[0].replace(/\//g, "-")
        this.setData({
            startDate: st,
            endDate: et
        })
        var set1 = []
        var set2 = []
        for(var i = 0; i < 45; ++i){
            set1.push(3)
            set2.push(3)
        }
        this.setData({
            classSet1: set1,
            classSet2: set2
        })
        var d = new Date()
        var temp = new Array()
        for(var i = 0; i <10; i++){
            var currentDate = formatTime(d).split(" ")[0].substr(5)
            temp[i] = currentDate
            d.setDate(d.getDate()+1)
        }
        this.setData({
            datesFirst: temp.splice(0,5),
            datesSecond: temp.splice(0,5)
        })
        this.getReserveRecord()
    },
    getReserveRecord(){
        wx.request({
            method: 'GET',
            url: 'http://81.68.229.2:686/APPOINTMENT-MODULE-SERVER/appointment/student/records',
            header:{
                Authorization: app.globalData.token
            },
            success: results => {
                this.setData({
                    reservedRecords: results.data.data
                })
                this.getApply()
            }
        })
    },
    getApply(){
        wx.request({
            method: 'GET',
            url: 'http://81.68.229.2:686/APPOINTMENT-MODULE-SERVER/appointment/student/notReviewedTimes',
            header:{
                Authorization: app.globalData.token
            },
            data:{
                startTime: this.__data__.startDate + ' 09:00:00',
                endTime: this.__data__.endDate + ' 21:00:00'
            },
            success: results => {
                this.setData({
                    applyRecords: results.data.data
                })
                this.getClasses()
            }
        })
    },
    getClasses(){
        wx.request({
            method: 'GET',
            url: 'http://81.68.229.2:686/APPOINTMENT-MODULE-SERVER/course/get/template',
            header:{
                Authorization: app.globalData.token
            },
            data:{
                endDate: this.__data__.endDate,
                startDate: this.__data__.startDate,
                trainerId: app.globalData.coachInfo.cid
            },
            success: results => {
                var res = results.data.data
                var tmpSet1 = this.__data__.classSet1
                var tmpSet2 = this.__data__.classSet2
                for(var i = 0; i < 45; ++i){
                    tmpSet1[i] = res[i]
                    if(res[i].course_info != null){
                        if(res[i].course_info.reserved >= res[i].course_info.limit){
                            tmpSet1[i].type = 0
                        }
                        // 体验课
                        if(res[i].course_info.type == 1){
                            if(app.globalData.banTrial==true){
                                tmpSet1[i].type = 0
                            }
                        }
                    }
                    tmpSet2[i] = res[i+45]
                    if(res[i+45].course_info != null){
                        if(res[i+45].course_info.reserved >= res[i+45].course_info.limit){
                            tmpSet2[i].type = 0
                        }

                        if(res[i+45].course_info.type == 1){
                            if(app.globalData.banTrial==true){
                                tmpSet2[i].type = 0
                            }
                        }
                    }
                }
                this.setData({
                    rawData: res,
                    classSet1: tmpSet1,
                    classSet2: tmpSet2
                })
                this.checkReserved()
            }
        })
    },
    checkReserved(){
        var reserved = this.__data__.reservedRecords
        for(var i = 0; i < reserved.length; ++i){
            var idx = this.timeToIndex(reserved[i].startTime)
            if(idx < 0){
                continue
            }
            if(idx > 44){
                var tmp = this.__data__.classSet2
                tmp[idx-45].type = 2
                this.setData({
                    classSet2: tmp
                })
            }
            else{
                var tmp = this.__data__.classSet1
                tmp[idx].type = 2
                this.setData({
                    classSet1: tmp
                })
            }
        }
        var applyed = this.__data__.applyRecords
        for(var i = 0; i < applyed.length; ++i){
            var idx = this.timeToIndex(applyed[i])
            if(idx < 0){
                continue
            }
            if(idx > 44){
                var tmp = this.__data__.classSet2
                tmp[idx-45].type = 3
                this.setData({
                    classSet2: tmp,
                    selectIndex: null
                })
            }
            else{
                var tmp = this.__data__.classSet1
                tmp[idx].type = 3
                this.setData({
                    classSet1: tmp,
                    selectIndex: null
                })
            }
        }
        wx.hideLoading()
    },
    timeToIndex(targetTime){
        var targetDate = targetTime.split(" ")[0].split("-")
        var targetHour = targetTime.split(" ")[1].split(":")[0]
        var hourIndex = -1;
        for(var i = 0; i < this.__data__.timeSections.length; ++i){
            var hour = this.__data__.timeSections[i].substr(0,2)
            if(targetHour == hour){
                hourIndex = i;
            }
        }
        var sd = this.__data__.startDate.split("-")
        var d1 = new Date()
        d1.setFullYear(targetDate[0],targetDate[1]-1,targetDate[2])
        d1.setHours(0,0,0,0)

        var d2 = new Date()
        d2.setFullYear(sd[0],sd[1]-1,sd[2])
        d2.setHours(0,0,0,0)
        var distance = (d1.getTime()-d2.getTime())/3600/24/1000
        return distance*9+hourIndex
    },
    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh: function () {
        this.getReserveRecord()
        wx.stopPullDownRefresh()
    },
})