// pages/shop/cart.js
const app = getApp()
Page({

    /**
     * 页面的初始数据
     */
    data: {
        delShow: false,
        radioCon: null,
        selectAll: false,
        carts: null,
        commoDetail: null,
        totalPrice: 0,
        bindTopTip: '',
        list: [{
            "text": "商店",
            "pagePath": "./shop",
            "iconPath": "../../../assets/icon/goods.png",
            "selectedIconPath": "../../../assets/icon/goodsS.png"
        },
        {
            "text": "购物车",
            "pagePath": "./cart",
            "iconPath": "../../../assets/icon/cart.png",
            "selectedIconPath": "../../../assets/icon/cartS.png",
            badge: '0'
        },
        {
            "text": "订单",
            "pagePath": "./order",
            "iconPath": "../../../assets/icon/shop_order.png",
            "selectedIconPath": "../../../assets/icon/shop_orderS.png"
        }]
    },
    tapTabbar(e){
        wx.redirectTo({
          url: e.detail.item.pagePath+'?badge='+this.__data__.list[1].badge,
        })
    },
    tapRadio(e){
        var tmp = this.__data__.radioCon
        tmp[parseInt(e.currentTarget.dataset.value)].selected = !tmp[parseInt(e.currentTarget.dataset.value)].selected
        this.setData({
            radioCon: tmp
        })
        this.checkCheck()
    },
    tapSelectAll(){
        var tmp = this.__data__.radioCon
        var target = !this.__data__.selectAll
        for(var i = 0; i < tmp.length; ++i){
            tmp[i].selected = target
        }
        this.setData({
            selectAll: target,
            radioCon: tmp
        })
        this.checkCheck()
    },
    checkCheck(){
        var tmp = this.__data__.radioCon
        var hasOne = false
        var tmpTotalPrice = 0
        for(var i = 0; i < tmp.length; ++i){
            if(tmp[i].selected == true){
                tmpTotalPrice += this.__data__.carts[i].commodityQuantity * this.__data__.commoDetail[i].price
                hasOne = true
            }
        }
        if(hasOne){
            this.setData({
                delShow: true,
                totalPrice: tmpTotalPrice
            })
        } else{
            this.setData({
                delShow: false,
                totalPrice: 0
            })
        }
    },
    /**
     * 生命周期函数--监听页面加载
     */
    onShow: function (options) {
        this.getCart()
    },
    refreshCartBadge(){
        var tmp = this.__data__.carts.length
        var tmpList = this.__data__.list
        tmpList[1].badge = tmp.toString()
        this.setData({
            list: tmpList
        })
    },
    getGoodsAndDivide(type){
        wx.request({
            method: 'GET',
            url: 'http://81.68.229.2:686/API-AGGREGATE/wx/getSellingCommodities',
            header:{
                Authorization: app.globalData.token
            },
            data:{
                orderType: type
            },
            success: results => {
                var res = results.data.data.commodities
                var tmp = []
                var tar = this.__data__.carts
                for(var i = 0; i < tar.length; ++i){
                    for(var j = 0; j < res.length; ++j){
                        if(res[j].id == tar[i].commodityId){
                            tmp[i] = res[j]
                            break
                        }
                    }
                }
                this.setData({
                    commoDetail: tmp
                })
            }
        })
    },
    getCart(){
        wx.request({
            method: 'GET',
            url: 'http://81.68.229.2:686/SHOP-MODULE-SERVER/shopping/user/shoppingCart',
            header:{
                Authorization: app.globalData.token
            },
            data:{
                uid: app.globalData.uid
            },
            success: results => {
                var res = results.data.content
                var tmpRadios = []
                for(var i = 0; i < res.length; ++i){
                    tmpRadios[i] = {cartId: res[i].id, selected: false}
                }
                this.setData({
                    carts: results.data.content,
                    radioCon: tmpRadios,
                    selectAll: false
                })
                this.getGoodsAndDivide(1)
                this.refreshCartBadge()
                this.checkCheck()
            }
        })
    },
    tapPay(){
        if(this.__data__.delShow){
            wx.showModal({
                title: '下单',
                content: '是否确认下单？',
                showCancel: true,
                confirmText: '确定',
                cancelText: '取消',
                success: res => {
                    if(res.confirm == true){
                        var selectedList = []
                        var tmp = this.__data__.radioCon
                        var count = 0
                        for(var i = 0; i < tmp.length; ++i){
                            if(tmp[i].selected){
                                selectedList[count++]=(tmp[i].cartId)
                            }
                        }
                        wx.request({
                            method: 'POST',
                            url: 'http://81.68.229.2:686/SHOP-MODULE-SERVER/shopping/user/createOrderInCart',
                            header:{
                                Authorization: app.globalData.token
                            },
                            data:{
                                shoppingCartIdList: selectedList
                            },
                            success: results => {
                                var res = results.data.content
                                for(var i = 0; i < res.length; ++i){
                                    // this.payOrder(res[i])
                                    this.deleteCart(selectedList[i])
                                }
                                wx.showLoading({
                                    title: '请稍等...',
                                })
                                setTimeout(() => {
                                    this.getCart()
                                }, 300);
                                setTimeout(() => {
                                    this.setData({
                                        delShow: false
                                    })
                                    wx.hideLoading()
                                    wx.redirectTo({
                                      url: 'order?badge='+this.__data__.list[1].badge+'&type=1',
                                    })
                                }, 1500);
                            }
                        })
                    }
                }
            })
        }
    },
    payOrder(orderId){
        wx.request({
            method: 'GET',
            url: 'http://81.68.229.2:686/SHOP-MODULE-SERVER//shopping/user/purchase',
            header:{
                Authorization: app.globalData.token
            },
            data:{
                orderId: orderId
            }
        })
    },
    tapAdd(e){
        var index = e.currentTarget.dataset.value
        var cart = this.__data__.carts
        ++cart[index].commodityQuantity
        this.modifyCart(cart[index].id, cart[index].commodityQuantity)
        this.setData({
            carts: cart
        })
    },
    tapMinus(e){
        var index = e.currentTarget.dataset.value
        var cart = this.__data__.carts
        if(cart[index].commodityQuantity > 1){
            --cart[index].commodityQuantity
            this.modifyCart(cart[index].id, cart[index].commodityQuantity)
            this.setData({
                carts: cart
            })
        }
        else{
            this.setData({
                bindTopTip: '不能再减少了喔~试试选中删除吧~'
            })
        }
    },
    tapDelete(){
        if(this.__data__.delShow){
            wx.showModal({
                title: '删除',
                content: '是否确认删除？',
                showCancel: true,
                confirmText: '确定',
                cancelText: '取消',
                success: res => {
                    if(res.confirm == true){
                        var tmp = this.__data__.radioCon
                        for(var i = 0; i < tmp.length; ++i){
                            if(tmp[i].selected){
                                this.deleteCart(tmp[i].cartId)
                            }
                        }
                        setTimeout(() => {
                            this.setData({
                                delShow: false
                            })
                            this.getCart()
                        }, 500);
                    }
                }
            })
        }
    },
    tapCard(e){
        wx.navigateTo({
            url: 'detail?id='+e.currentTarget.dataset.value
          })
    },
    modifyCart(cartId, quantity){
        wx.request({
            method: 'POST',
            url: 'http://81.68.229.2:686/SHOP-MODULE-SERVER/shopping/user/modifyShoppingCart?cartId='+cartId+'&quantity='+quantity,
            header:{
                Authorization: app.globalData.token
            },
            success: results => {
                this.checkCheck()
            }
        })
    },
    deleteCart(cartId){
        wx.request({
            method: 'GET',
            url: 'http://81.68.229.2:686/SHOP-MODULE-SERVER/shopping/user/removeShoppingCart',
            header:{
                Authorization: app.globalData.token
            },
            data:{
                cartId: cartId
            }
        })
    }
})