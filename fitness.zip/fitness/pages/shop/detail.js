// pages/shop/detail.js
const app = getApp()
Page({

    /**
     * 页面的初始数据
     */
    data: {
        goodInfo: null,
        totalPrice: 0,
        itemCount: 0,
        price: 0,
        cartId: null,
        commoId: null
    },

    /**
     * 生命周期函数--监听页面加载
     */
    onLoad: function (options) {
        this.getCommoDetail(parseInt(options.id))
        this.getCart(parseInt(options.id))
        this.setData({
            commoId: parseInt(options.id)
        })
    },
    getCommoDetail(id){
        wx.request({
            method: 'GET',
            url: 'http://81.68.229.2:686/SHOP-MODULE-SERVER/shopping/user/commodity',
            header:{
                Authorization: app.globalData.token
            },
            data:{
                commodityId: id
            },
            success: results => {
                this.setData({
                    goodInfo: results.data.content,
                    price: results.data.content.price
                })
            }
          })
    },
    // 1 查询 2 修改 3 数量0新增 4 数量1删除
    getCart(commoId){
        wx.request({
            method: 'GET',
            url: 'http://81.68.229.2:686/SHOP-MODULE-SERVER/shopping/user/shoppingCart',
            header:{
                Authorization: app.globalData.token
            },
            data:{
                uid: app.globalData.uid
            },
            success: results => {
                var res = results.data.content
                var tmpCartId = null
                var tmpCount = null
                for(var i = 0; i < res.length; ++i){
                    if(res[i].commodityId==commoId){
                        tmpCartId = res[i].id
                        tmpCount = res[i].commodityQuantity
                    }
                }
                this.setData({
                    cartId: tmpCartId,
                    itemCount: tmpCount,
                    totalPrice: this.__data__.price*tmpCount
                })
                if(tmpCount == null){
                    this.setData({
                        itemCount: 0
                    })
                }
            }
        })
    },
    tapMinus(){
        var commoId = this.__data__.commoId
        var cartId = this.__data__.cartId
        var tmp = this.__data__.itemCount
        if(tmp >= 1){
            if(tmp == 1){
                tmp = 0
                this.deleteCart(cartId)
            }
            else{
                --tmp
                this.modifyCart(cartId, tmp)
            }
            this.setData({
                itemCount: tmp,
                totalPrice: this.__data__.price*tmp
            })
        }
    },
    tapAdd(){
        var commoId = this.__data__.commoId
        var cartId = this.__data__.cartId
        var tmp = this.__data__.itemCount
        if(tmp == 0){
            tmp = 1
            this.addNewToCart(commoId)
        }
        else{
            ++tmp
            this.modifyCart(cartId, tmp)
        }
        this.setData({
            itemCount: tmp,
            totalPrice: this.__data__.price*tmp
        })
    },
    tapBack(){
        wx.navigateBack({
          delta: 1,
        })
    },
    modifyCart(cartId, quantity){
        wx.request({
            method: 'POST',
            url: 'http://81.68.229.2:686/SHOP-MODULE-SERVER/shopping/user/modifyShoppingCart?cartId='+cartId+'&quantity='+quantity,
            header:{
                Authorization: app.globalData.token
            }
        })
    },
    addNewToCart(commoId){
        wx.request({
            method: 'POST',
            url: 'http://81.68.229.2:686/SHOP-MODULE-SERVER/shopping/user/addShoppingCart',
            header:{
                Authorization: app.globalData.token
            },
            data:{
                commodityId: commoId,
                commodityQuantity: 1
            },
            success: results => {
                this.getCart(commoId)
            }
        })
    },
    deleteCart(cartId){
        wx.request({
            method: 'GET',
            url: 'http://81.68.229.2:686/SHOP-MODULE-SERVER/shopping/user/removeShoppingCart',
            header:{
                Authorization: app.globalData.token
            },
            data:{
                cartId: cartId
            }
        })
    }
})