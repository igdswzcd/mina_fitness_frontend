// pages/shop/order.js
const app =getApp()
const { formatTime } = require("../../utils/util")
Page({

    /**
     * 页面的初始数据
     */
    data: {
        orders: [],
        commoDetail: [],
        orderTimes: [],
        list: [{
            "text": "商店",
            "pagePath": "./shop",
            "iconPath": "../../../assets/icon/goods.png",
            "selectedIconPath": "../../../assets/icon/goodsS.png"
        },
        {
            "text": "购物车",
            "pagePath": "./cart",
            "iconPath": "../../../assets/icon/cart.png",
            "selectedIconPath": "../../../assets/icon/cartS.png",
            badge: '0'
        },
        {
            "text": "订单",
            "pagePath": "./order",
            "iconPath": "../../../assets/icon/shop_order.png",
            "selectedIconPath": "../../../assets/icon/shop_orderS.png"
        }]
    },
    tapTabbar(e){
        wx.redirectTo({
            url: e.detail.item.pagePath+'?badge='+this.__data__.list[1].badge,
          })
    },

    /**
     * 生命周期函数--监听页面加载
     */
    onLoad: function (options) {
        if(options.type==1){
            wx.showModal({
                title: '下单完成',
                content: '请前往健身房自提取货',
                showCancel: false,
                confirmText: '确定'
            })
        }
        this.getOrders()
        var tmp = this.__data__.list
        tmp[1].badge = options.badge
        this.setData({
            list: tmp
        })
    },
    getOrders(){
        wx.request({
            method: 'GET',
            url: 'http://81.68.229.2:686/API-AGGREGATE/wx/getAllOrders',
            header:{
                Authorization: app.globalData.token
            },
            success: results => {
                if(results.data.data.orders != null){
                    this.setData({
                        orders: results.data.data.orders.reverse()
                    })
                    this.getGoods(1)
                    this.setTime()
                }
            }
        })
    },
    getGoods(type){
        wx.request({
            method: 'GET',
            url: 'http://81.68.229.2:686/API-AGGREGATE/wx/getSellingCommodities',
            header:{
                Authorization: app.globalData.token
            },
            data:{
                orderType: type
            },
            success: results => {
                var res = results.data.data.commodities
                var tmp = []
                var tmpOrder = this.__data__.orders
                for(var i = 0; i < tmpOrder.length; ++i){
                    var tmpInnerArray = []
                    for(var j = 0; j < tmpOrder[i].orderList.length; ++j){
                        for(var k = 0; k < res.length; ++k){
                            if(res[k].id == tmpOrder[i].orderList[j].commodityId){
                                tmpInnerArray.push({images:res[k].images, name:res[k].name, price:res[k].price})
                                break
                            }
                        }
                    }
                    console.log(tmpInnerArray)
                    tmp.push(tmpInnerArray)
                }
                this.setData({
                    commoDetail: tmp
                })
            }
        })
    },
    setTime(){
        var tmp = this.__data__.orders
        var tmpTimes = []
        for(var i = 0; i < tmp.length; ++i){
            tmpTimes.push(formatTime(new Date(tmp[i].createTime)))
        }
        this.setData({
            orderTimes: tmpTimes
        })
    }
})