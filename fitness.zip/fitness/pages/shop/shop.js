// pages/shop/shop.js
const app = getApp()

Page({

    /**
     * 页面的初始数据
     */
    data: {
        show: false,
        selectData: ['默认', '价格↑', '价格↓', '销量↓'],
        index: 0,
        goods: null,
        goodCount: null,
        list: [{
            "text": "商店",
            "pagePath": "shop",
            "iconPath": "../../../assets/icon/goods.png",
            "selectedIconPath": "../../../assets/icon/goodsS.png"
        },
        {
            "text": "购物车",
            "pagePath": "cart",
            "iconPath": "../../../assets/icon/cart.png",
            "selectedIconPath": "../../../assets/icon/cartS.png",
            badge: '0'
        },
        {
            "text": "订单",
            "pagePath": "order",
            "iconPath": "../../../assets/icon/shop_order.png",
            "selectedIconPath": "../../../assets/icon/shop_orderS.png"
        }]
    },
    onShow(){
        this.getGoods(1)
    },
    getGoods(type){
        wx.request({
            method: 'GET',
            url: 'http://81.68.229.2:686/API-AGGREGATE/wx/getSellingCommodities',
            header:{
                Authorization: app.globalData.token
            },
            data:{
                orderType: type
            },
            success: results => {
                var len = results.data.data.commodities.length
                var tmp = []
                for(var i = 0; i < len; ++i){
                    tmp[i] = 0
                }
                this.setData({
                    goods: results.data.data.commodities,
                    goodCount: tmp,
                    search: this.search.bind(this)
                })
                this.getCart(1, -1, -1)
            }
        })
    },
    // type = 1 获取各商品在购物车中的数量
    // type = 0 获取商品id对应的购物车id修改数量
    // type = 2 获取商品对应购物车id，删除
    getCart(type, cValue, amount){
        wx.request({
            method: 'GET',
            url: 'http://81.68.229.2:686/SHOP-MODULE-SERVER/shopping/user/shoppingCart',
            header:{
                Authorization: app.globalData.token
            },
            data:{
                uid: app.globalData.uid
            },
            success: results => {
                if(type == 0){
                    var res = results.data.content
                    var tmpCartId = null
                    for(var i = 0; i < res.length; ++i){
                        if(res[i].commodityId==cValue){
                            tmpCartId = res[i].id
                        }
                    }
                    this.modifyCart(tmpCartId, amount)
                }
                else if(type == 1){
                    this.refreshGoodCount(results.data.content)
                }
                else if(type == 2){
                    var res = results.data.content
                    var tmpCartId = null
                    for(var i = 0; i < res.length; ++i){
                        if(res[i].commodityId==cValue){
                            tmpCartId = res[i].id
                        }
                    }
                    this.deleteCart(tmpCartId)
                }
            }
        })
    },
    refreshGoodCount(results){
        var tmp = this.__data__.goodCount
        for(var i = 0; i < tmp.length; ++i){
            for(var j = 0; j < results.length; ++j){
                if(this.__data__.goods[i].id==results[j].commodityId){
                    tmp[i] = results[j].commodityQuantity
                }
            }
        }
        this.setData({
            goodCount: tmp
        })
        this.refreshCartBadge()
    },
    search(value){
        var tmp = this.__data__.goods
        var reg = new RegExp(value, "i")
        var list = []
        var count = 0
        for(var i = 0; i < tmp.length; ++i){
            if(tmp[i].name.search(reg) >= 0){
                list[count] = {text: tmp[i].name, value: tmp[i].id}
                count++
            }
        }
        return new Promise((resolve, reject) => {
            setTimeout(() => {
                resolve(list)
            }, 50)
        })
    },
    selectResult(e){
        wx.navigateTo({
          url: 'detail?id='+e.detail.item.value
        })
    },
    selectTap(){
        this.setData({
            show : !this.__data__.show
        })
    },
    optionTap(e){
        var idx = e.currentTarget.dataset.index
        this.setData({
            index: idx,
            show: !this.__data__.show
        })
        this.getGoods(idx+1)
    },
    tapCard(e){
        wx.navigateTo({
            url: 'detail?id='+e.currentTarget.dataset.value
          })
    },
    addToCart(e){
        // e.currentTarget.dataset.value=要+1的商品id
        // e.currentTarget.dataset.index=当前排列下的商品index
        var cValue = e.currentTarget.dataset.value
        var cIndex = e.currentTarget.dataset.index
        // 购物车为0，加入购物车，否则修改购物车内物品数量
        if(this.__data__.goodCount[cIndex] == 0){
            var tmp = this.__data__.goodCount
            tmp[cIndex]++
            this.setData({
                goodCount: tmp
            })
            this.addNewToCart(cValue)
        }
        else{
            var tmp = this.__data__.goodCount
            tmp[cIndex]++
            this.setData({
                goodCount: tmp
            })
            this.getCart(0, cValue, tmp[cIndex])
        }
        this.refreshCartBadge()
    },
    addNewToCart(commoId){
        wx.request({
            method: 'POST',
            url: 'http://81.68.229.2:686/SHOP-MODULE-SERVER/shopping/user/addShoppingCart',
            header:{
                Authorization: app.globalData.token
            },
            data:{
                commodityId: commoId,
                commodityQuantity: 1
            }
        })
    },
    minusToCart(e){
        // e.currentTarget.dataset.value=要+1的商品id
        // e.currentTarget.dataset.index=当前排列下的商品index
        var cValue = e.currentTarget.dataset.value
        var cIndex = e.currentTarget.dataset.index
        // 购物车为1，删除购物车，否则修改购物车内物品数量
        if(this.__data__.goodCount[cIndex] == 1){
            var tmp = this.__data__.goodCount
            --tmp[cIndex]
            this.setData({
                goodCount: tmp
            })
            this.getCart(2, cValue, -1)
        }
        else{
            var tmp = this.__data__.goodCount
            --tmp[cIndex]
            this.setData({
                goodCount: tmp
            })
            this.getCart(0, cValue, tmp[cIndex])
        }
        this.refreshCartBadge()
    },
    deleteCart(cartId){
        wx.request({
            method: 'GET',
            url: 'http://81.68.229.2:686/SHOP-MODULE-SERVER/shopping/user/removeShoppingCart',
            header:{
                Authorization: app.globalData.token
            },
            data:{
                cartId: cartId
            }
        })
    },
    refreshCartBadge(){
        var tmp = this.__data__.goodCount
        var badgeCount = 0
        for(var i = 0; i < tmp.length; ++i){
            if(tmp[i] > 0){
                ++badgeCount
            }
        }
        var tmpList = this.__data__.list
        tmpList[1].badge = badgeCount.toString()
        this.setData({
            list: tmpList
        })
    },
    tapTabbar(e){
        wx.redirectTo({
            url: e.detail.item.pagePath+'?badge='+this.__data__.list[1].badge,
          })
    },

    modifyCart(cartId, quantity){
        wx.request({
            method: 'POST',
            url: 'http://81.68.229.2:686/SHOP-MODULE-SERVER/shopping/user/modifyShoppingCart?cartId='+cartId+'&quantity='+quantity,
            header:{
                Authorization: app.globalData.token
            }
        })
    },
})