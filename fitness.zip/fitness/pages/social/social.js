// pages/social/social.js
const app = getApp()
Page({

	/**
	 * 页面的初始数据
	 */
	data: {
		textFocus: false,
		placeholder: '[分享]',
		inputTarget: -1,				// -1 =发表share，>=0 =发表评论
		inputText: '',
		reachBottom: false,
		lastScroll: 0,
		shares: null
	},
	tapLike(e){
		var idx = e.currentTarget.dataset.index
		if(this.__data__.shares[idx].isSelfLike == 0){
			var tmp = this.__data__.shares
			tmp[idx].isSelfLike = 1
			console.log(tmp[idx].id)
			wx.request({
				method: 'POST',
				url: 'http://81.68.229.2:686/USER-MODULE-SERVER/community/like?id='+tmp[idx].id,
				header:{
					Authorization: app.globalData.token
				},
				success: results => {
					console.log(results)
					this.setData({
						shares: tmp
					})
				}
			})
		}
	},
	bindInput(e){
		this.setData({
			inputText: e.detail.value
		})
	},
	tapAdd(){
		this.setData({
			textFocus: true,
			inputTarget: -1,
			placeholder: '[分享]',
		})
	},
	tapComment(e){
		var idx = e.currentTarget.dataset.index
		this.setData({
			textFocus: true,
			inputTarget: idx,
			placeholder: '[评论]',
		})
	},
	tapSubmit(){
		if(this.__data__.inputText!=''){
			if(this.__data__.inputTarget == -1){
				this.submitShare()
			}
			else{
				this.submitComment()
			}
		}
	},
	submitShare(){
		wx.request({
			method: 'POST',
			url: 'http://81.68.229.2:686/USER-MODULE-SERVER/community/add',
			header:{
				Authorization: app.globalData.token
			},
			data:{
				content: this.__data__.inputText,
				likeCounts: 0,
				type: 0,
				userId: app.globalData.uid
			},
			success: results => {
				this.setData({
					inputText: ''
				})
				this.getAllShare()
			}
		})
	},
	submitComment(){
		wx.request({
			method: 'POST',
			url: 'http://81.68.229.2:686/USER-MODULE-SERVER/community/comment',
			header:{
				Authorization: app.globalData.token
			},
			data:{
				comment: this.__data__.inputText,
				fromUserId: app.globalData.uid,
				shareId: this.__data__.shares[this.__data__.inputTarget].id
			},
			success: results => {
				this.setData({
					inputText: ''
				})
				this.getAllShare()
			}
		})
	},
	/**
	 * 生命周期函数--监听页面加载
	 */
	onLoad: function (options) {
		this.getAllShare()
	},
	getAllShare(){
		wx.request({
            method: 'GET',
            url: 'http://81.68.229.2:686/API-AGGREGATE/wx/getAllShare',
            header:{
                Authorization: app.globalData.token
            },
            success: results => {
                this.setData({
                    shares: results.data.data
                })
            }
        })
	},
	onPullDownRefresh(e){
		this.getAllShare()
		wx.stopPullDownRefresh()
	},

	/**
	 * 页面相关事件处理函数--监听用户下拉动作
	 */
	onPageScroll(e) {
		var last = this.__data__.lastScroll
		this.setData({
			lastScroll: e.scrollTop
		})
		if(e.scrollTop < last){
			this.setData({
				reachBottom: false
			})
		}
	},
	/**
	 * 页面上拉触底事件的处理函数
	 */
	onReachBottom: function () {
		this.setData({
			reachBottom: true
		})
	},

	/**
	 * 用户点击右上角分享
	 */
	onShareAppMessage: function () {

	}
})