// pages/stucoach/stucoach.js
const app = getApp()
Page({

	/**
	 * 页面的初始数据
	 */
	data: {
		scores: ['○○○○○','●○○○○','●●○○○','●●●○○','●●●●○','●●●●●'],
		coachInfo: null,
		comments: [{id:'?', userId:'?', coachId:'?', score:0, comment:'暂时没有评论哦！'}],
		bottomType: 0,
		inputText: '',
		score: 0
	},
	tapChat(){
		this.setData({
			bottomType: 1
		})
	},
	tapComment(){
		this.setData({
			bottomType: 2
		})
	},
	tapBack(){
		this.setData({
			bottomType: 0,
			inputText: '',
			score: 0
		})
	},
	bindInput(e){
		this.setData({
			inputText: e.detail.value
		})
	},
	sliderChange(e){
		console.log(e)
		this.setData({
			score: e.detail.value
		})
	},
	tapSubmit(){
		if(this.__data__.bottomType == 1){
			this.chatWithCoach()
		}
		else if(this.__data__.bottomType == 2){
			this.commentCoach()
		}
	},
	chatWithCoach(){
		wx.request({
			method: 'POST',
			url: 'http://81.68.229.2:686/APPOINTMENT-MODULE-SERVER/message/chat',
			header:{
				Authorization: app.globalData.token
			},
			data:{
				content: this.__data__.inputText,
  				senderId: app.globalData.uid,
  				targetId: this.__data__.coachInfo.cid
			},
			success: results => {
				this.tapBack()
			}
		})
	},
	commentCoach(){
		wx.request({
			method: 'POST',
			url: 'http://81.68.229.2:686/USER-MODULE-SERVER/evaluate/add',
			header:{
				Authorization: app.globalData.token
			},
			data:{
				coachId: this.__data__.coachInfo.cid,
				comment: this.__data__.inputText,
				score: this.__data__.score,
				userId: app.globalData.uid
			},
			success: results => {
				this.setData({
					bottomType: 0,
					inputText: '',
					score: 0
				})
				this.getComments()
			}
		})
	},
	/**
	 * 生命周期函数--监听页面加载
	 */
	onLoad: function (options) {
		this.setData({
			coachInfo: app.globalData.coachInfo
		})
		this.getComments()
	},
	getComments(){
		wx.request({
			method: 'GET',
			url: 'http://81.68.229.2:686/USER-MODULE-SERVER/evaluate/get/coach',
			header:{
				Authorization: app.globalData.token
			},
			data:{
				coachId: this.__data__.coachInfo.cid
			},
			success: results => {
				if(results.data.content.length > 0){
					this.setData({
						comments: results.data.content.reverse()
					})
				}
			}
		})
	},
	/**
	 * 页面相关事件处理函数--监听用户下拉动作
	 */
	onPullDownRefresh: function () {
		this.getComments()
		wx.stopPullDownRefresh()
	}
})